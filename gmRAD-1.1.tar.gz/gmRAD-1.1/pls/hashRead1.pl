#!/usr/bin/perl -w

#    Copyright 2018 Chunfa Tong (tongchf@njfu.edu.cn)

#    This file is a part of gmRAD.

#    gmRAD is a free software package; you can redistribute it and/or 
#    modify it under the terms of the GNU General Public License as 
#    published by the Free Software Foundation; either version 3 of 
#    the License, or (at your option) any later version.

#    gmRAD is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with gmRAD. If not, see <http://www.gnu.org/licenses/>.

use strict;
use warnings;
use Switch;
use Parallel::ForkManager;
use Getopt::Long;

sub prtHelp{
    print "This program is used to cluster the first reads from RAD-seq\n";
    print "Contact: Chunfa Tong  <tongchf\@njfu.edu.cn>\n";
    print "Usage: perl hashRead1.pl <read1.fq> <out.hash> [options]\n";
    print "\n";
    print "Options:\n";
    print "       -m  <int> minimum number of reads in a cluster [5]\n";
    print "       -x  <int> maximum number of reads in a cluster [200]\n";
    print "       --help|h  help\n";
}

my $i;
my $n;
my %hash;
my $line;
my ($key,$value);
my @flds;
my $help;
my $m;
my $x;

if(@ARGV<2){
     	prtHelp();
	exit;
}

GetOptions(
      	"m:i"=>\$m,
      	"x:i"=>\$x,
	"help|h" => \$help
);

if($help){
     	prtHelp();
	exit;
}

unless($m){
	$m = 5;
}
unless($x){
	$x = 200;
}

open(IN,"<$ARGV[0]") || die "Error: cannot open the file $ARGV[0]\n";
$i = 0;
while($line = <IN>){
	$line = <IN>;
	chop $line;
	if(exists($hash{$line})){
		$hash{$line} = "$hash{$line}  $i";
	}else{
		$hash{$line} = $i;
	}
	$line = <IN>;
	$line = <IN>;
	$i++;
}
close(IN);

open(OUT,">$ARGV[1]");
foreach $key (keys %hash){
	$value = $hash{$key};
	@flds = split /\s+/,$value;
	$n = scalar @flds;
	if($n >= $m && $n <= $x){
		print OUT "$value\n";
		print OUT "$key\n";
	}
}
close(OUT);

exit;
