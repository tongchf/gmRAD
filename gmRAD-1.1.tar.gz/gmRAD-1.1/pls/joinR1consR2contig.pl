#!/usr/bin/perl -w

#    Copyright 2018 Chunfa Tong (tongchf@njfu.edu.cn)

#    This file is a part of gmRAD.

#    gmRAD is a free software package; you can redistribute it and/or 
#    modify it under the terms of the GNU General Public License as 
#    published by the Free Software Foundation; either version 3 of 
#    the License, or (at your option) any later version.

#    gmRAD is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with gmRAD. If not, see <http://www.gnu.org/licenses/>.

use strict;
use warnings;

my ($r1,$r2,$rvr2);
my $joinrst;
my $clsi;

if(@ARGV < 3){
	print "This program is used to join the consensus of the first reads with the longest contig of the second reads in a RAD-seq cluster.\n";
	die "Usage: perl joinR1consR2contig.pl <read1_cons.fasta> <read2-contig.fasta> <clsi>\n";
}

open(R1,"<$ARGV[0]") || die "Error: cannot open the file $ARGV[0].\n";
open(R2,"<$ARGV[1]") || die "Error: cannot open the file $ARGV[1].\n";
$r1 = <R1>;
$r1 = <R1>;
chop $r1;
$r2 = <R2>;
$r2 = <R2>;
chop $r2;
close(R1);
close(R2);

$clsi = $ARGV[2];

$joinrst = joinr12($r1,$r2);

if($joinrst eq -1){
	$rvr2 = reverse $r2;
	$rvr2 =~ tr/ACGT/TGCA/;
	$joinrst = joinr12($r1,$rvr2);
}

if($joinrst eq -1){
	$joinrst = $r1 . "NNNNNNNNNN" . $r2;
}

open(OUT,">Cls$clsi\_R1joinR2\_ref.fasta");
print OUT ">CLS$clsi\n";
print OUT "$joinrst\n";
close OUT;

exit;

sub joinr12{
	my ($r1,$r2) = @_;
	my ($i,$j);
	my ($n,$n1,$n2);
	my ($sr1,$sr2);
	my ($r1head5,$r2head5);
	my ($r1head5b,$r2head5b);
	my (@ps,$nps);
	my $result;
	my $offset;
	my $overlaprst;
	my $joinseq12 = "";

	$n1 = length($r1);
	$n2 = length($r2);
	$r1head5 = substr($r1,0,5);
	$r2head5 = substr($r2,0,5);

	@ps = ();
	$offset = 0;
	$result = index($r1,$r2head5,$offset);
	while($result != -1){
		push @ps,$result;
		$offset = $result + 5;
		$result = index($r1,$r2head5,$offset);
	}
	$nps = scalar @ps;

	if($nps !=0){
		for($i=0;$i<$nps;$i++){
			$sr1 = substr($r1,$ps[$i]);
			$n = $n1 - $ps[$i];
			$sr2 = substr($r2,0,$n);
			$overlaprst = overlapcase($sr1,$sr2,$n);
			if($overlaprst == 1){
				$joinseq12 = $r1 . substr($r2,$n);
				return $joinseq12;
			}
		}
	}

	for($i=0;$i<5;$i++){
		$r2head5b = $r2head5;
		substr($r2head5b,$i,1) = "[ACGT]";
		@ps = ();
		while($r1 =~ /$r2head5b/g){
			push @ps,pos($r1)-5;
		}
		$nps = scalar @ps;
		if($nps !=0){
			for($j=0;$j<$nps;$j++){
				$sr1 = substr($r1,$ps[$j]);
				$n = $n1 - $ps[$j];
				$sr2 = substr($r2,0,$n);
				$overlaprst = overlapcase($sr1,$sr2,$n);
				if($overlaprst == 1){
					$joinseq12 = $r1 . substr($r2,$n);
					return $joinseq12;
				}
			}
		}
	}

	@ps = ();
	$offset = 0;
	$result = index($r2,$r1head5,$offset);
	while($result != -1){
		push @ps,$result;
		$offset = $result + 5;
		$result = index($r2,$r2head5,$offset);
	}
	$nps = scalar @ps;

	if($nps !=0){
		for($i=0;$i<$nps;$i++){
			$n = $n2 - $ps[$i];
			if($n>=$n1){
				$sr2 = substr($r2,$ps[$i],$n1);
				$overlaprst = overlapcase($r1,$sr2,$n1);
				if($overlaprst == 1){
					$joinseq12 = substr($r2,$ps[$i]);
					return $joinseq12;
				}
			}
		}
	}
	
	for($i=0;$i<5;$i++){
		$r1head5b = $r1head5;
		substr($r1head5b,$i,1) = "[ACGT]";
		@ps = ();
		while($r2 =~ /$r1head5b/g){
			push @ps,pos($r2)-5;
		}
		$nps = scalar @ps;
		if($nps !=0){
			for($j=0;$j<$nps;$j++){
				$n = $n2 - $ps[$j];
				if($n>=$n1){
					$sr2 = substr($r2,$ps[$j],$n1);
					$overlaprst = overlapcase($r1,$sr2,$n1);
					if($overlaprst == 1){
						$joinseq12 = substr($r2,$ps[$j]);
						return $joinseq12;
					}
				}
			}
		}
	}

	return(-1);
}

sub overlapcase{
	my ($s1,$s2,$n) = @_;
	my ($i,$j);
	my $dst = 0;
	my $flag = -1;
	my $threshod;

	for($i=0;$i<$n;$i++){
		if(substr($s1,$i,1) ne substr($s2,$i,1)){
			$dst++;
		}
	}
	
	if($dst <= int($n*0.2) && $dst < 6){ 
		$flag = 1; 
	}
	return $flag;
}
