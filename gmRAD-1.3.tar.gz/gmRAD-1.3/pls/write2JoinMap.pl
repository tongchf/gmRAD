#! /usr/bin/perl -w

#    Copyright 2018 Chunfa Tong (tongchf@njfu.edu.cn)

#    This file is a part of gmRAD.

#    gmRAD is a free software package; you can redistribute it and/or 
#    modify it under the terms of the GNU General Public License as 
#    published by the Free Software Foundation; either version 3 of 
#    the License, or (at your option) any later version.

#    gmRAD is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with gmRAD. If not, see <http://www.gnu.org/licenses/>.

use strict;
use warnings;
use Getopt::Long;
use Excel::Writer::XLSX;

sub prtHelp{
    print "This program is used to write all the SNP genotype data to an excel file in JoinMap format.\n";
    print "Contact: Chunfa Tong <tongchf\@njfu.edu.cn>\n";
    print "\n";
    print "Usage: perl write2JoinMap.pl\n";
    print "\n";
    print "Parameters:\n";
    print "       -c <int> percent of the non-missing genotypes [90]\n";
    print "       -p <float> minimum p value [0.01]\n";
    print "       -n <float> the number of progeny\n";
    print "       --help|h  help\n";
    print "\n";
}

my $pct;
my $pv;
my $line;
my @flds;
my ($n,$i,$j);
my $outf1;
my $outf2;
my $outf3;
my $outf4;
my $outf5;
my $outf6;
my $outf7;
my $allout;
my ($workbook,$sheet);
my $help;

GetOptions(
	"c:i"=>\$pct,
	"p:f"=>\$pv,
	"n:i"=>\$n,
	'help|h' => \$help
);

if($help){
	prtHelp();
	exit;
}

unless($pct){ $pct = 90; }
unless($pv){ $pv = 0.01; }
unless($n){ $n = 10; }

if($pct < 50 || $pct > 100){
	die "Error: Invalid value of the percent!\n";
}
if($pv < 0 || $pv > 1.0){
	die "Error: Invalid p value!\n";
}
if($n < 0 ){
	die "Error: Invalid n value!\n";
}

$outf1 = sprintf("aaxab_pct%dpv%02d.txt",$pct,$pv*100);
$outf2 = sprintf("aaxbc_pct%dpv%02d.txt",$pct,$pv*100);
$outf3 = sprintf("abxaa_pct%dpv%02d.txt",$pct,$pv*100);
$outf4 = sprintf("abxcc_pct%dpv%02d.txt",$pct,$pv*100);
$outf5 = sprintf("abxab_pct%dpv%02d.txt",$pct,$pv*100);
$outf6 = sprintf("abxcd_pct%dpv%02d.txt",$pct,$pv*100);
$outf7 = sprintf("abxac_pct%dpv%02d.txt",$pct,$pv*100);

$allout = sprintf("all_pct%dpv%02d_joinmap.xlsx",$pct,$pv*100);
$workbook = Excel::Writer::XLSX->new($allout);
$sheet = $workbook->add_worksheet();
$i = 0;
for($j=0;$j<4;$j++){
	$sheet->write($i,$j,'');
}
for($j=1;$j<=$n;$j++){
	$sheet->write($i,$j+3,$j);
}

open(IN,"<$outf3") || die "Error: cannnot open the file $outf3!\n";
$line = <IN>;
while(<IN>){
	$i++;
	chop $_;
	@flds = split /\s+/,$_;
	$sheet->write($i,0,$flds[0]);
	$sheet->write($i,1,'<lmxll>');
	$sheet->write($i,2,'');
	$sheet->write($i,3,'(ll,lm)');
	shift @flds;
	shift @flds;
	foreach(@flds){
		s/aa/ll/;
		s/ab/lm/;
	}
	for($j=0;$j<$n;$j++){
		$sheet->write($i,$j+4,$flds[$j]);
	}
}
close(IN);

open(IN,"<$outf1") || die "Error: cannnot open the file $outf1!\n";
$line = <IN>;
while(<IN>){
	$i++;
	chop $_;
	@flds = split /\s+/,$_;
	$sheet->write($i,0,$flds[0]);
	$sheet->write($i,1,'<nnxnp>');
	$sheet->write($i,2,'');
	$sheet->write($i,3,'(nn,np)');
	shift @flds;
	shift @flds;
	foreach(@flds){
		s/aa/nn/;
		s/ab/np/;
	}
	for($j=0;$j<$n;$j++){
		$sheet->write($i,$j+4,$flds[$j]);
	}
}
close(IN);

open(IN,"<$outf5") || die "Error: cannnot open the file $outf5!\n";
$line = <IN>;
while(<IN>){
	$i++;
	chop $_;
	@flds = split /\s+/,$_;
	$sheet->write($i,0,$flds[0]);
	$sheet->write($i,1,'<hkxhk>');
	$sheet->write($i,2,'');
	$sheet->write($i,3,'(hh,hk,kk)');
	shift @flds;
	shift @flds;
	foreach(@flds){
		s/aa/hh/;
		s/ab/hk/;
		s/bb/kk/;
	}
	for($j=0;$j<$n;$j++){
		$sheet->write($i,$j+4,$flds[$j]);
	}
}
close(IN);

open(IN,"<$outf6") || die "Error: cannnot open the file $outf6!\n";
$line = <IN>;
while(<IN>){
	$i++;
	chop $_;
	@flds = split /\s+/,$_;
	$sheet->write($i,0,$flds[0]);
	$sheet->write($i,1,'<abxcd>');
	$sheet->write($i,2,'');
	$sheet->write($i,3,'(ab,ad,bc,bd)');
	shift @flds;
	shift @flds;
	for($j=0;$j<$n;$j++){
		$sheet->write($i,$j+4,$flds[$j]);
	}
}
close(IN);

open(IN,"<$outf4") || die "Error: cannnot open the file $outf4!\n";
$line = <IN>;
while(<IN>){
	$i++;
	chop $_;
	@flds = split /\s+/,$_;
	$sheet->write($i,0,$flds[0]);
	$sheet->write($i,1,'<lmxll>');
	$sheet->write($i,2,'');
	$sheet->write($i,3,'(ll,lm)');
	shift @flds;
	shift @flds;
	foreach(@flds){
		s/ac/ll/;
		s/bc/lm/;
	}
	for($j=0;$j<$n;$j++){
		$sheet->write($i,$j+4,$flds[$j]);
	}
}
close(IN);

open(IN,"<$outf2") || die "Error: cannnot open the file $outf2!\n";
$line = <IN>;
while(<IN>){
	$i++;
	chop $_;
	@flds = split /\s+/,$_;
	$sheet->write($i,0,$flds[0]);
	$sheet->write($i,1,'<nnxnp>');
	$sheet->write($i,2,'');
	$sheet->write($i,3,'(nn,np)');
	shift @flds;
	shift @flds;
	foreach(@flds){
		s/ab/nn/;
		s/ac/np/;
	}
	for($j=0;$j<$n;$j++){
		$sheet->write($i,$j+4,$flds[$j]);
	}
}
close(IN);

open(IN,"<$outf7") || die "Error: cannnot open the file $outf7!\n";
$line = <IN>;
while(<IN>){
	$i++;
	chop $_;
	@flds = split /\s+/,$_;
	$sheet->write($i,0,$flds[0]);
	$sheet->write($i,1,'<efxeg>');
	$sheet->write($i,2,'');
	$sheet->write($i,3,'(ee,ef,eg,fg)');
	shift @flds;
	shift @flds;
	foreach(@flds){
		s/aa/ee/;
		s/ab/ef/;
		s/ac/eg/;
		s/bc/fg/;
	}
	for($j=0;$j<$n;$j++){
		$sheet->write($i,$j+4,$flds[$j]);
	}
}
close(IN);

exit;

