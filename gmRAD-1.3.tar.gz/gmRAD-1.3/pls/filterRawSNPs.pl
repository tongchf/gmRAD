#!/usr/bin/perl -w

#    Copyright 2018 Chunfa Tong (tongchf@njfu.edu.cn)

#    This file is a part of gmRAD.

#    gmRAD is a free software package; you can redistribute it and/or 
#    modify it under the terms of the GNU General Public License as 
#    published by the Free Software Foundation; either version 3 of 
#    the License, or (at your option) any later version.

#    gmRAD is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with gmRAD. If not, see <http://www.gnu.org/licenses/>.

use strict;
use warnings;
use Statistics::Distributions;

my ($i,$j);
my @fd;
my ($n,$m);
my ($n1,$n2,$n3,$n4);
my @gtp;
my %hash;
my $segtype;
my ($gtpcount,$otherscount);
my $key;
my ($x2,$mean,$pv);
my @prgGTPs;
my $head;
my $p12gtp;
my $sgrgtp0;
my @sgrgtps;
my $ng;
my %subhash;

my %sgrt =('A|A A|A' => 'aaxaa: A|A',
           'A|A C|C' => 'aaxbb: A|C',
           'A|A G|G' => 'aaxbb: A|G',
           'A|A T|T' => 'aaxbb: A|T',
           'C|C A|A' => 'aaxbb: A|C',
           'C|C C|C' => 'aaxaa: C|C',
           'C|C G|G' => 'aaxbb: C|G',
           'C|C T|T' => 'aaxbb: C|T',
           'G|G A|A' => 'aaxbb: A|G',
           'G|G C|C' => 'aaxbb: C|G',
           'G|G G|G' => 'aaxaa: G|G',
           'G|G T|T' => 'aaxbb: G|T',
           'T|T A|A' => 'aaxbb: A|T',
           'T|T C|C' => 'aaxbb: C|T',
           'T|T G|G' => 'aaxbb: G|T',
           'T|T T|T' => 'aaxaa: T|T',
           'A|A A|C' => 'aaxab: A|A A|C', 
           'A|A A|G' => 'aaxab: A|A A|G',
           'A|A A|T' => 'aaxab: A|A A|T',
           'C|C A|C' => 'aaxab: C|C A|C',
           'C|C C|G' => 'aaxab: C|C C|G',
           'C|C C|T' => 'aaxab: C|C C|T',
           'G|G A|G' => 'aaxab: G|G A|G',
           'G|G C|G' => 'aaxab: G|G C|G',
           'G|G G|T' => 'aaxab: G|G G|T',
           'T|T A|T' => 'aaxab: T|T A|T',
           'T|T C|T' => 'aaxab: T|T C|T',
           'T|T G|T' => 'aaxab: T|T G|T',
           'A|C A|A' => 'abxaa: A|A A|C',
           'A|G A|A' => 'abxaa: A|A A|G',
           'A|T A|A' => 'abxaa: A|A A|T',
           'A|C C|C' => 'abxaa: C|C A|C',
           'C|G C|C' => 'abxaa: C|C C|G',
           'C|T C|C' => 'abxaa: C|C C|T',
           'A|G G|G' => 'abxaa: G|G A|G',
           'C|G G|G' => 'abxaa: G|G C|G',
           'G|T G|G' => 'abxaa: G|G G|T',
           'A|T T|T' => 'abxaa: T|T A|T',
           'C|T T|T' => 'abxaa: T|T C|T',
           'G|T T|T' => 'abxaa: T|T G|T',
           'A|A C|G' => 'aaxbc: A|C A|G', 
           'A|A C|T' => 'aaxbc: A|C A|T', 
           'A|A G|T' => 'aaxbc: A|G A|T', 
           'C|C A|G' => 'aaxbc: A|C C|G', 
           'C|C A|T' => 'aaxbc: A|C C|T', 
           'C|C G|T' => 'aaxbc: C|G C|T', 
           'G|G A|C' => 'aaxbc: A|G C|G', 
           'G|G A|T' => 'aaxbc: A|G G|T', 
           'G|G C|T' => 'aaxbc: C|G G|T', 
           'T|T A|C' => 'aaxbc: A|T C|T', 
           'T|T A|G' => 'aaxbc: A|T G|T', 
           'T|T C|G' => 'aaxbc: C|T G|T', 
           'C|G A|A' => 'abxcc: A|C A|G', 
           'C|T A|A' => 'abxcc: A|C A|T', 
           'G|T A|A' => 'abxcc: A|G A|T', 
           'A|G C|C' => 'abxcc: A|C C|G', 
           'A|T C|C' => 'abxcc: A|C C|T', 
           'G|T C|C' => 'abxcc: C|G C|T', 
           'A|C G|G' => 'abxcc: A|G C|G', 
           'A|T G|G' => 'abxcc: A|G G|T', 
           'C|T G|G' => 'abxcc: C|G G|T', 
           'A|C T|T' => 'abxcc: A|T C|T', 
           'A|G T|T' => 'abxcc: A|T G|T', 
           'C|G T|T' => 'abxcc: C|T G|T', 
           'A|C A|C' => 'abxab: A|A A|C C|C', 
           'A|G A|G' => 'abxab: A|A A|G G|G', 
           'A|T A|T' => 'abxab: A|A A|T T|T', 
           'C|G C|G' => 'abxab: C|C C|G G|G', 
           'C|T C|T' => 'abxab: C|C C|T T|T', 
           'G|T G|T' => 'abxab: G|G G|T T|T', 
           'A|C G|T' => 'abxcd: A|G A|T C|G C|T', 
           'A|G C|T' => 'abxcd: A|C A|T C|G G|T', 
           'A|T C|G' => 'abxcd: A|C A|G C|T G|T', 
           'C|G A|T' => 'abxcd: A|C C|T A|G G|T', 
           'C|T A|G' => 'abxcd: A|C C|G A|T G|T', 
           'G|T A|C' => 'abxcd: A|G C|G A|T C|T', 
           'A|C A|G' => 'abxac: A|A A|C A|G C|G', 
           'A|C A|T' => 'abxac: A|A A|C A|T C|T', 
           'A|G A|C' => 'abxac: A|A A|G A|C C|G', 
           'A|G A|T' => 'abxac: A|A A|G A|T G|T', 
           'A|T A|C' => 'abxac: A|A A|T A|C C|T', 
           'A|T A|G' => 'abxac: A|A A|T A|G G|T', 
           'A|C C|G' => 'abxac: C|C A|C C|G A|G', 
           'A|C C|T' => 'abxac: C|C A|C C|T A|T', 
           'C|G A|C' => 'abxac: C|C C|G A|C A|G', 
           'C|G C|T' => 'abxac: C|C C|G C|T G|T', 
           'C|T A|C' => 'abxac: C|C C|T A|C A|T', 
           'C|T C|G' => 'abxac: C|C C|T C|G G|T', 
           'A|G C|G' => 'abxac: G|G A|G C|G A|C', 
           'A|G G|T' => 'abxac: G|G A|G G|T A|T', 
           'C|G A|G' => 'abxac: G|G C|G A|G A|C', 
           'C|G G|T' => 'abxac: G|G C|G G|T C|T', 
           'G|T A|G' => 'abxac: G|G G|T A|G A|T', 
           'G|T C|G' => 'abxac: G|G G|T C|G C|T', 
           'A|T C|T' => 'abxac: T|T A|T C|T A|C', 
           'A|T G|T' => 'abxac: T|T A|T G|T A|G', 
           'C|T A|T' => 'abxac: T|T C|T A|T A|C', 
           'C|T G|T' => 'abxac: T|T C|T G|T C|G', 
           'G|T A|T' => 'abxac: T|T G|T A|T A|G', 
           'G|T C|T' => 'abxac: T|T G|T C|T C|G' );
my %sg2gtp = ( 'aaxab' => 'aa ab',
               'abxaa' => 'aa ab',
               'abxab' => 'aa ab bb',
               'aaxbc' => 'ab ac',
               'abxcc' => 'ac bc',
               'abxcd' => 'ac ad bc bd',
               'abxac' => 'aa ab ac bc' );

if(@ARGV<2){ die "Usage: perl filterRawSNPs.pl <gmRawSNPs.txt> <gmRawSNPs2.txt>\n"; }

open(IN,"<$ARGV[0]");
$head = <IN>;
chop $head;
@fd = split /\t/,$head;
$m = scalar @fd;
$head = join "\t",@fd[4..($m-1)];
$head = "$fd[0]\t$fd[1]\t$fd[2]\t$fd[3]\tSegType\tGtpCount\tOthersCount\tN\tX2\tPValue\t".$head;

open(OUT,">$ARGV[1]");
print OUT "$head\n";

while(<IN>){
	chop $_;
	@fd = split /\t/,$_;
	$m = scalar @fd;
	$p12gtp = "$fd[2] $fd[3]";
	if(!exists( $sgrt{$p12gtp} )){
		$segtype = "NA";
	}else{
		($segtype,$sgrgtp0) = split /:\s+/,$sgrt{$p12gtp};
		@gtp = split /\s+/,$sgrgtp0;
		$ng = scalar @gtp;
	}
	%hash = ();
	for($j=4;$j<$m;$j++){
		$hash{$fd[$j]}++;
	}
	@prgGTPs = @fd[4..($m-1)];

	if($segtype eq "NA"){
		$gtpcount = "NA";
		$otherscount = "";
		foreach $key (sort keys %hash){
			$otherscount = $otherscount."$key:$hash{$key};";
		}
		if($otherscount =~/;$/){
			chop $otherscount;
		}
		$otherscount =~ s/\./NA/g;
		if($otherscount eq ""){
			$otherscount = "NA:0";
		}
		print OUT "$fd[0]\t$fd[1]\t$fd[2]\t$fd[3]\t$segtype\t$gtpcount\t$otherscount\n";
	}else{
		if($ng == 2){
			if(exists $hash{$gtp[0]}){ 
				$n1 = $hash{$gtp[0]}; 
			}else{ 
				$n1 = 0; 
			}
			if(exists $hash{$gtp[1]}){ 
				$n2 = $hash{$gtp[1]}; 
			}else{ 
				$n2 = 0; 
			}
			$n = $n1 + $n2;
			if($n > 2){
				$mean = $n/2;
				$x2 = ($n1-$mean)**2/$mean + ($n2-$mean)**2/$mean;
				$pv = Statistics::Distributions::chisqrprob(1,$x2);
			}else{
				$x2 = 99.0;
				$pv = 0.0;
			}
		}

		if($ng == 3){
			if(exists $hash{$gtp[0]}){ 
				$n1 = $hash{$gtp[0]}; 
			}else{ 
				$n1 = 0; 
			}
			if(exists $hash{$gtp[1]}){ 
				$n2 = $hash{$gtp[1]}; 
			}else{ 
				$n2 = 0; 
			}
			if(exists $hash{$gtp[2]}){ 
				$n3 = $hash{$gtp[2]}; 
			}else{ 
				$n3 = 0; 
			}
			$n = $n1 + $n2 + $n3;
			if($n > 3){
				$mean = $n/4;
				$x2 = ($n1-$mean)**2/$mean + ($n2-2*$mean)**2/(2*$mean) + ($n3-$mean)**2/$mean;
				$pv = Statistics::Distributions::chisqrprob(2,$x2);
			}else{
				$x2 = 99.0;
				$pv = 0.0;
			}
		}

		if($ng == 4){
			if(exists $hash{$gtp[0]}){ 
				$n1 = $hash{$gtp[0]}; 
			}else{ 
				$n1 = 0; 
			}
			if(exists $hash{$gtp[1]}){ 
				$n2 = $hash{$gtp[1]}; 
			}else{ 
				$n2 = 0; 
			}
			if(exists $hash{$gtp[2]}){ 
				$n3 = $hash{$gtp[2]}; 
			}else{ 
				$n3 = 0; 
			}
			if(exists $hash{$gtp[3]}){ 
				$n4 = $hash{$gtp[3]}; 
			}else{ 
				$n4 = 0; 
			}
			$n = $n1 + $n2 + $n3 + $n4;
			if($n > 4){
				$mean = $n/4;
				$x2 = ($n1-$mean)**2 + ($n2-$mean)**2 + ($n3-$mean)**2 + ($n4-$mean)**2;
				$x2 = $x2/$mean;
				$pv = Statistics::Distributions::chisqrprob(3,$x2);
			}else{
				$x2 = 99.0;
				$pv = 0.0;
			}
		}

		$gtpcount = "";
		for($j=0;$j<$ng;$j++){
			if(exists $hash{$gtp[$j]}){
				$gtpcount = $gtpcount."$gtp[$j]:$hash{$gtp[$j]};";
				delete $hash{$gtp[$j]};
			}else{
				$gtpcount = $gtpcount."$gtp[$j]:0;";
			}
		}
		chop $gtpcount;
		$otherscount = "";
		foreach $key (sort keys %hash){
			$otherscount = $otherscount."$key:$hash{$key};";
		}
		if($otherscount =~/;$/){
			chop $otherscount;
		}
		$otherscount =~ s/\./NA/g;
		if($otherscount eq ""){
			$otherscount = "NA:0";
		}
		
		if($ng == 1){
			print OUT "$fd[0]\t$fd[1]\t$fd[2]\t$fd[3]\t$segtype\t$gtpcount\t$otherscount\n";
		}else{
			@sgrgtps = split /\s+/,$sg2gtp{$segtype};
			%subhash = ();
			for($i=0;$i<$ng;$i++){
				$subhash{$gtp[$i]} = $sgrgtps[$i];
			}

			for($j=0;$j<($m-4);$j++){
				if( exists( $subhash{$prgGTPs[$j]} ) ){
					$prgGTPs[$j] = $subhash{$prgGTPs[$j]};
				}else{
					$prgGTPs[$j] = "--";
				}
			}
			print OUT "$fd[0]\t$fd[1]\t$fd[2]\t$fd[3]\t$segtype\t$gtpcount\t$otherscount\t";
			printf OUT ("$n\t%8.2f\t%6.4f\t",$x2,$pv);
			print OUT join "\t",@prgGTPs;
			print OUT  "\n";
		}
	}

}

close OUT;
close IN;

exit;

