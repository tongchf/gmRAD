#!/usr/bin/perl -w 

#    Copyright 2018 Chunfa Tong (tongchf@njfu.edu.cn)

#    This file is a part of gmRAD.

#    gmRAD is a free software package; you can redistribute it and/or 
#    modify it under the terms of the GNU General Public License as 
#    published by the Free Software Foundation; either version 3 of 
#    the License, or (at your option) any later version.

#    gmRAD is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with gmRAD. If not, see <http://www.gnu.org/licenses/>.

use strict;
use Getopt::Std;

our($opt_i,$opt_l,$opt_f,$opt_a,$opt_o);

getopt('i:l:f:a:o');

my $input = "";
my $min_overlap = 0;
my $max_overlap = 0;
my $step_overlap = 0;
my $format;
my @tt;
my $i = 0;
my $cmd;
my $output;
my $LOCASfold="";
my $name;

if (!defined $opt_i || !defined $opt_l || !defined $opt_f || !defined $opt_a || !defined $opt_o){
	if (!defined $opt_i){
		print "\n-i option is missing\n\n";
		&usage();
		exit(0);
	}
	if (!defined $opt_l){
		print "\n-l option is missing\n\n";
		&usage();
		exit(0);
	}
	if (!defined $opt_f){
		print "\n-f option is missing\n\n";
		&usage();
		exit(0);
	}
	if (!defined $opt_a){
		print "\n-a option is missing\n\n";
		&usage();
		exit(0);
	}
	if (!defined $opt_o){
		print "\n-o option is missing\n\n";
		&usage();
		exit(0);
	}
}
elsif(defined $opt_i && defined $opt_l && defined $opt_f && defined $opt_a && defined $opt_o){
	$input = $opt_i;
	@tt = split(/-/,$opt_l);
	if (scalar(@tt) !=3){	
		print "Rang for overlap has the wrong format\n";
		&usage();
		exit(0);
	}
	else{
		$min_overlap = $tt[0];
		$max_overlap = $tt[1];
		$step_overlap = $tt[2];
	}
	$format = $opt_f;
	$LOCASfold = $opt_a;
	$output = $opt_o;
	$name = $opt_o;
}

my $maxlth = 0;
my $strlth = 0;
my $line1;
my $line2;
my %hash;
my $fa;

for ($i=$min_overlap;$i<=$max_overlap;$i=$i+$step_overlap){
	$cmd = "$LOCASfold\/locas -I $input -O tmp_locas -F $format -L $i";
	system ($cmd);
	open (IN,"tmp_locas/contigs.fasta")or die;
	while ($line1=<IN>){
		$line2=<IN>;
		chop $line2;
		$maxlth =length($line2);
		if ($maxlth > $strlth){
			$strlth = $maxlth;
			$fa = "$line2\n";		
		}
	}
}
open (OUT,">$output")or die;
print OUT ">$name\_read2_long_congtig\n$fa";

$cmd = "rm -r tmp_locas";
system ($cmd);

exit;

sub usage(){
	print "Usage: $0 -i input-file -l overlap length -f format -a LOCASfold -o output-file -n name
	-i input file with second illumina reads
	-l range of overlap length tested,minimal_overlap_length- maximal_overlap_length-size_of_steps
		e.g. 21-27-2,means overlap lengths 21,23,25 and 27 are used
	-f the format of the second illumina reads,fasta or fatsq
	-a path to LOCAS
	-o the output file\n";
}
