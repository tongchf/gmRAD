#! /usr/bin/perl -w

#    Copyright 2018 Chunfa Tong (tongchf@njfu.edu.cn)

#    This file is a part of gmRAD.

#    gmRAD is a free software package; you can redistribute it and/or 
#    modify it under the terms of the GNU General Public License as 
#    published by the Free Software Foundation; either version 3 of 
#    the License, or (at your option) any later version.

#    gmRAD is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with gmRAD. If not, see <http://www.gnu.org/licenses/>.

use strict;
use warnings;
use Getopt::Long;
use Parallel::ForkManager;

my $bwafold;
my $samtoolsfold;
my $bcftoolsfold;
my $reffile;
my ($i,$j,$k);
my ($f1fq,$f2fq,$m1fq,$m2fq);
my $cmd;
my $flag;
my $prefix1;
my $prefix2;
my @prefix;
my $help;
my ($pm,$pid);
my $fold;
my @pfq;
my $mismatch;
my $outprfx;

sub prtHelp{
	print "\nThis program is used to call parental SNPs and generate a specific locus file for calling SNPs in progeny. The common reference file is used directly for the whole parental fastq data.\n\n";
	print "Contact: Chunfa Tong <tongchf\@njfu.edu.cn>\n";
	print "Usage: perl findParentsSNPsM2.pl <-f ref.fa> <-f1 read1.fq> <-f2 read2.fq> ...\n\n";
	print "Parameters are accepted as following:\n";
	print "		-r  <str>	the reference file in fasta format\n";
	print "		-f1 <str>	the read1 fastq file of the female parent\n";
	print "		-f2 <str>	the read2 fastq file of the female parent\n";
	print "		-m1 <str>	the read1 fastq file of the male parent\n";
	print "		-m2 <str>	the read2 fastq file of the male parent\n";
	print "		-b  <str>	BWA fold\n";
	print "		-s  <str>	SAMtools fold\n";
	print "		-c  <str>	BCFtools fold\n";
	print "		-n  <int>	maximum edit distance (i.e. NM:i:xxx in SAM file)\n";
	print "		-o  <str>	prefix of output files\n";
	print "		--help | -h	help\n";
	exit;
}

GetOptions(
	"r:s"=>\$reffile,
	"f1:s"=>\$f1fq,
	"f2:s"=>\$f2fq,
	"m1:s"=>\$m1fq,
	"m2:s"=>\$m2fq,
	"b:s"=>\$bwafold,
	"s:s"=>\$samtoolsfold,
	"c:s"=>\$bcftoolsfold,
	"n:i"=>\$mismatch,
	"o:s"=>\$outprfx,
	"help|h"=>\$help
);

if($help){
	prtHelp();
	exit;
}

unless($reffile){
	print STDERR "\nError: the reference fasta file was not provided!\n\n";
	prtHelp();
	exit;
}

unless($f1fq){
	print STDERR "\nError: the read1 fastq file of the female parent was not provided!\n\n";
	prtHelp();
	exit;
}

unless($f2fq){
	print STDERR "\nError: the read2 fastq file of the female parent was not provided!\n\n";
	prtHelp();
	exit;
}

unless($m1fq){
	print STDERR "\nError: the read1 fastq file of the male parent was not provided!\n\n";
	prtHelp();
	exit;
}

unless($m2fq){
	print STDERR "\nError: the read2 fastq file of the male parent was not provided!\n\n";
	prtHelp();
	exit;
}

unless($bwafold){
	print STDERR "\nError: BWA fold was not provided!\n\n";
	prtHelp();
	exit;
}

unless($samtoolsfold){
	print STDERR "\nError: SAMtools fold was not provided!\n\n";
	prtHelp();
	exit;
}

unless($bcftoolsfold){
	print STDERR "\nError: BCFtools fold was not provided!\n\n";
	prtHelp();
	exit;
}

unless($mismatch){
	print STDERR "\nError: the edit distance was not provided!\n\n";
	prtHelp();
	exit;
}

unless($outprfx){
	print STDERR "\nError: the prefix of output files was not provided!\n\n";
	prtHelp();
	exit;
}

($flag,$prefix1) = &prefixfq($f1fq,$f2fq);

if($flag == 1){
	push @prefix,$prefix1;
	print "prefix = $prefix1\n\n";
}else{
	die "Error: the two fastq file names of the female parent are not consistent!\n";
}

($flag,$prefix1) = &prefixfq($m1fq,$m2fq);

if($flag == 1){
	push @prefix,$prefix1;
	print "prefix = $prefix1\n\n";
}else{
	die "Error: the two fastq file names of the male parent are not consistent!\n";
}

print "\@prefix: @prefix\n";

@pfq =([$f1fq,$f2fq],[$m1fq,$m2fq]);

print "\n$pfq[0][0],$pfq[0][1],$pfq[1][0],$pfq[1][1]\n";

my @flds = ("CallFemaleParent","CallMaleParent");

$pm = new Parallel::ForkManager(2);
for($i=0;$i<2;$i++){
	$pid = $pm->start and next;
	$fold = $flds[$i];

	if(-e $fold){
		system("rm -rf $fold");
	}
	mkdir $fold;
	system("cp $reffile $fold");
	chdir $fold;

	$cmd = "$bwafold\/bwa index  $reffile";
	system($cmd);
	
	$cmd = "$bwafold\/bwa mem $reffile $pfq[$i][0] $pfq[$i][1] > $prefix[$i].sam";
	system($cmd);

	filterParentSAM("$prefix[$i].sam","$prefix[$i].b.sam",$mismatch);
 		
	$cmd = "$samtoolsfold\/samtools view -b -S -o $prefix[$i].bam $prefix[$i].b.sam";
	system($cmd);
	
	$cmd = "$samtoolsfold\/samtools sort $prefix[$i].bam -o $prefix[$i].sorted.bam";
	system($cmd);
	$cmd = "$samtoolsfold\/samtools index $prefix[$i].sorted.bam";
	system($cmd);

#	$cmd = "$samtoolsfold\/samtools mpileup -uv -t DPR,INFO/DPR -g -f $reffile $prefix[$i].sorted.bam > $prefix[$i].bcf";
	$cmd = "$bcftoolsfold\/bcftools mpileup -Obuzv -a AD,INFO/AD -f $reffile $prefix[$i].sorted.bam > $prefix[$i].bcf";
	system($cmd);

	$cmd = "$bcftoolsfold\/bcftools call -m -v -f gq $prefix[$i].bcf | awk '\$1!~/^#/' > $prefix[$i].vcf";
	system($cmd);
	
	filterParentVcf("$prefix[$i].vcf","$prefix[$i].loc");	

	$cmd = "awk '{print \$1\"\\t\"\$2}' $prefix[$i].loc > $prefix[$i].c12.loc";
	system($cmd);
	system("cp $prefix[$i].c12.loc ..");
	system("rm *.sam");

	$pm->finish;
}
$pm->wait_all_children;

$cmd = "cat $prefix[0].c12.loc $prefix[1].c12.loc | sort | uniq > fm.sorted.uniq.loc";
system($cmd);

$cmd = "sort -n -k 1.4 -k 2 fm.sorted.uniq.loc > fm.snp.loc";
system($cmd);

$cmd = "$bcftoolsfold\/bcftools call -m -f gq -T fm.snp.loc $flds[0]/$prefix[0].bcf | awk '\$1!~/^#/' > $prefix[0].loc.vcf";
system($cmd);

$cmd = "$bcftoolsfold\/bcftools call -m -f gq -T fm.snp.loc $flds[1]/$prefix[1].bcf | awk '\$1!~/^#/' > $prefix[1].loc.vcf";
system($cmd);

my %hash;

%hash = ();
open(SNP,"<fm.snp.loc");
while(<SNP>){
	chop $_;
	$hash{$_} = ".\t.";	
}
close SNP;

my @fd;
my $key;
my @allels;
my $gtp0;
my ($a1,$a2);
my @gtp;
my ($dp0,$dp1,$dp2,@dp);
my $gq;

open(SNP,"<$prefix[0].loc.vcf");
while(<SNP>){
	chop $_;
	@fd = split /\t/,$_;
	$key = "$fd[0]\t$fd[1]";
	if(exists $hash{$key} && $fd[7] !~ /INDEL/){
	#	if($fd[8] =~ /GT:DPR/){
		if($fd[8] =~ /GT:AD/){
			($gtp0,$dp0) = split /:/,$fd[9];
			if($gtp0 eq "0\/0" && $dp0 > 2){
				$hash{$key} =~ s/.*\t/$fd[3]|$fd[3]\t/;
			}
		}
	#	if($fd[8] =~ /GT:PL:DPR:GQ/){
		if($fd[8] =~ /GT:PL:AD:GQ/){
			if($fd[4]=~/,/){
				@allels = ($fd[3],(split /,/,$fd[4]));
			}else{
				@allels = ($fd[3],$fd[4]);
			}
			($gtp0,undef,$dp0,$gq) = split /:/,$fd[9];
			($a1,$a2) = split /\//,$gtp0;
			@dp = split /,/,$dp0;
			if($a1 == $a2){
				$dp0 = $dp[$a1];
				if($dp0 > 2){
					$gtp0 = "$allels[$a1]|$allels[$a1]";		
					$hash{$key} =~ s/.*\t/$gtp0\t/;
				}		
			}else{
				$dp1 = $dp[$a1];
				$dp2 = $dp[$a2];
				if($dp1>2 && $dp2>2 && $gq>30){
					@gtp = sort ($allels[$a1],$allels[$a2]);
					$hash{$key} =~ s/.*\t/$gtp[0]|$gtp[1]\t/;	
				}
			}
		}
	}
}
close SNP;

open(SNP,"<$prefix[1].loc.vcf");
while(<SNP>){
	chop $_;
	@fd = split /\t/,$_;
	$key = "$fd[0]\t$fd[1]";
	if(exists $hash{$key} && $fd[7] !~ /INDEL/){
	#	if($fd[8] =~ /GT:DPR/){
		if($fd[8] =~ /GT:AD/){
			($gtp0,$dp0) = split /:/,$fd[9];
			if($gtp0 eq "0\/0" && $dp0 > 2){
				$hash{$key} =~ s/\t.*/\t$fd[3]|$fd[3]/;
			}
		}
#		if($fd[8] =~ /GT:PL:DPR:GQ/){
		if($fd[8] =~ /GT:PL:AD:GQ/){
			if($fd[4]=~/,/){
				@allels = ($fd[3],(split /,/,$fd[4]));
			}else{
				@allels = ($fd[3],$fd[4]);
			}
			($gtp0,undef,$dp0,$gq) = split /:/,$fd[9];
			($a1,$a2) = split /\//,$gtp0;
			@dp = split /,/,$dp0;
			if($a1 == $a2){
				$dp0 = $dp[$a1];
				if($dp0 > 2){
					$gtp0 = "$allels[$a1]|$allels[$a1]";		
					$hash{$key} =~ s/\t.*/\t$gtp0/;
				}		
			}else{
				$dp1 = $dp[$a1];
				$dp2 = $dp[$a2];
				if($dp1>2 && $dp2>2 && $gq>30){
					@gtp = sort ($allels[$a1],$allels[$a2]);
					$hash{$key} =~ s/\t.*/\t$gtp[0]|$gtp[1]/;	
				}
			}
		}
	}
}
close SNP;

open(GTP,">$outprfx.gtp0");
foreach $key (keys %hash){
	print GTP "$key\t$hash{$key}\n";
}
close(GTP);

$cmd = "awk '\$3!~\/\\.\/ && \$4!~\/\\.\/' $outprfx.gtp0 > $outprfx.gtp1";
system($cmd);
$cmd = "sort -n -k 1.4 -k 2 $outprfx.gtp1 > $outprfx.gtp";
system($cmd);

$cmd = "awk '{print \$1\"\\t\"\$2}' $outprfx.gtp > $outprfx\_gtp.loc";
system($cmd);

exit;

sub filterParentVcf{

	#	print "Usage: filterParentVcf(in.vcf,out.loc)\n";
	my ($inputvcf,$outputloc) = @_;

	open(FILE,"<$inputvcf") || die "Could not open the VCF file\n";
	open(OUTVCF,">$outputloc");

	my @fd;
	my ($dp0,$dp1,$dp2,$gtp0,$gq);
	my @dp;
	my ($a1,$a2);

	while( <FILE> )
	{
		chomp $_;
		@fd = split /\t/,$_;
		if($fd[7]=~/INDEL/){
			next;
		}
	#	if($fd[8] =~ /GT:DPR/){
		if($fd[8] =~ /GT:AD/){
			($gtp0,$dp0) = split /:/,$fd[9];
			if($gtp0 eq "0\/0" && $dp0 > 2){
				print OUTVCF  "$fd[0]\t$fd[1]\t$fd[3]\t$fd[4]\t$dp0\n";
			}
		}
	#	if($fd[8] =~ /GT:PL:DPR:GQ/){
		if($fd[8] =~ /GT:PL:AD:GQ/){
			($gtp0,undef,$dp0,$gq) = split /:/,$fd[9];
			($a1,$a2) = split /\//,$gtp0;
			@dp = split /,/,$dp0;
			if($a1 == $a2){
				$dp0 = $dp[$a1];
				if($dp0 > 2){
					print OUTVCF  "$fd[0]\t$fd[1]\t$fd[3]\t$fd[4]\t$dp0\n";
				}		
			}else{
				$dp1 = $dp[$a1];
				$dp2 = $dp[$a2];
				if($dp1>2 && $dp2>2 && $gq>30){
					print OUTVCF  "$fd[0]\t$fd[1]\t$fd[3]\t$fd[4]\t$dp1\t$dp2\n";
				}
			}
		}

	}

	close(FILE);
	close(OUTVCF);
}

sub filterParentSAM{
	#	print "Usage: filterParentSAM(in.sam,out.sam,mismatch)\n";
	my ($inputsam,$outputsam,$msmt) = @_;
	my @fd;
	my $lth;
	my ($minas,$maxxs);

	open(FILE,"<$inputsam") || die "Could not open the SAM file\n";
	open(OUT,">$outputsam");

	while(<FILE>){
		if($_=~/^\@SQ/){
			print OUT $_;
			next;
		}

#111111111111111111111111111111111111111111111111111
		if($_=~/^\@PG/){
			print OUT $_;
			next;
		}
#111111111111111111111111111111111111111111111111111
		@fd = split /\s+/,$_;
		if($fd[2] eq "*" || $fd[3] == $fd[7] || ($fd[3] != 1 && $fd[7] != 1)){
			next;
		}
	#	if(/NM:i:(\d+)\s+AS:i:(\d+)\s+XS:i:(\d+)/){
		if(/NM:i:(\d+).*AS:i:(\d+)\s+XS:i:(\d+)/){
			$lth = length($fd[9]);
			$minas = $lth - $msmt*5;
			$maxxs = $lth - $msmt*10;
			if($2>$3 && (($fd[3]==1 && $2>=$minas) || ($fd[7]==1 && $2>=$maxxs))){ 
#			if( $1<=$msmt && $2>=$3 && $2>=$minas ){ 
				print OUT $_;
			}
		}
	}
	close FILE;
	close OUT;
}

sub prefixfq{
	my ($fq1,$fq2) = @_;
	my $i;
	my ($n1,$n2);
	my ($s1,$s2);
	my $prefix;
	my @tmp;

	$n1 = length($fq1);
	$n2 = length($fq2);

	if($n1 != $n2){
		return (0,"");
	}

	for($i=0;$i<$n1;$i++){
		$s1 = substr($fq1,$i,1);
		$s2 = substr($fq2,$i,1);
		if($s1 ne $s2 && $s1 eq "1" && $s2 eq "2" && $i>0){
			$prefix = substr($fq1,0,$i);
			$prefix =~ s/[-\_\._]$//;
			if($prefix=~/\//){
				@tmp = split /\//,$prefix;
				$prefix = pop @tmp;
			}
			return (1,$prefix);
		}	
	}

	return (0,"");
}
