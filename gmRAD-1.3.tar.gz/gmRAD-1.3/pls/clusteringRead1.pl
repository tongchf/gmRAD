#!/usr/bin/perl -w

#    Copyright 2018 Chunfa Tong (tongchf@njfu.edu.cn)

#    This file is a part of gmRAD.

#    gmRAD is a free software package; you can redistribute it and/or 
#    modify it under the terms of the GNU General Public License as 
#    published by the Free Software Foundation; either version 3 of 
#    the License, or (at your option) any later version.

#    gmRAD is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with gmRAD. If not, see <http://www.gnu.org/licenses/>.

use strict;
use warnings;
use Switch;
use Parallel::ForkManager;
use Getopt::Long;

sub prtHelp{
    print "This program is used to cluster the first reads from RAD-seq\n";
    print "Contact: Chunfa Tong  <tongchf\@njfu.edu.cn>\n";
    print "Usage: perl clusteringRead1.pl [Options]  <read1.fq> \n";
    print "\n";
    print "Options:\n";
    print "       -t <int> the number of threads to be used\n";
    print "       -d <int> the maximum hamming distance within a cluster\n";
    print "       -r <int> the percent of repeat regions on genome\n";
    print "       -o <string>  the prefix of output file for the clusters\n";
    print "       -p <string> the path to gmRAD.pl\n";
    print "       --help|h  help\n";
}

my @sects;
my ($i,$j,$k);
my ($j1,$j2);
my $cmd;
my ($pm,$pid);
my $threads;
my ($n,$d);
my $fqfile;
my $dst;
my $pct1;
my $pct;
my $x;
my $subfold = "clsfls";
my $outfile;
my $gmradfold;
my $help;
my $line;
my @flds;
my ($key,$value);
my @keys;
my %hash;

if(@ARGV==0){
     	prtHelp();
	exit;
}

GetOptions(
      	"t:i"=>\$threads,
      	"d:i"=>\$dst,
      	"r:i"=>\$pct,
	"o:s"=>\$outfile,
	"p:s"=>\$gmradfold,
	"help|h" => \$help
);

if($help){
	prtHelp();
	exit;
}

if(@ARGV==0){
     	prtHelp();
	exit;
}else{
	if($ARGV[0] =~ /fq/ || $ARGV[0] =~ /fastq/){
		$fqfile = $ARGV[0];
	}else{
		print "\nError: The input file may be in a wrong format\!\n\n";
		print "argv0 = $ARGV[0]\n";
     		prtHelp();
		exit;
	}
}

$cmd = "perl $gmradfold\/pls\/hashRead1.pl $fqfile $outfile.hash -m 1 -x 10000000";
system($cmd);
$cmd = "perl $gmradfold\/pls\/distribR1Hash.pl $outfile.hash";
system($cmd);

open(IN,"<distribution\_for\_$outfile.hash") || die "Error: cannot open the file 'distribution_for_$outfile.hash!\n";
$line = <IN>;
$line = <IN>;
chop $line;
@flds = split /\s+/,$line;
$pct1 = $flds[6];
$pct1 = 100 - $pct + $pct1;
while(<IN>){
	chop $_;
	@flds = split /\s+/,$_;
	if($flds[6] >= $pct1){
		$x = $flds[1];
		last;
	}
}
close(IN);

%hash = ();
$i = 0;
open(IN2,"<$outfile.hash") || die "Error: cannot open the file $outfile.hash!\n";
while($value = <IN2>){
	chop $value;
	@flds = split /\s+/,$value;
	$n = scalar @flds;
	if($n>4 && $n<=$x){
		$key = <IN2>;
		chop $key;	
		$hash{$key} = $value;
		$i++;
	}else{
		$key = <IN2>;
	}
}
close(IN2);
$n = $i;

print "x = $x, n = $n\n";

@keys = keys %hash;
$n = scalar @keys;
print "cls num in hash: n = $n\n";

open(OUT,">$outfile.hash.fa2");
$i = 0;
foreach $key (@keys){
	$value = $hash{$key};
	print OUT "CLS$i: $value\n$key\n";
	$i++;
}
close(OUT);

unless($threads){ $threads=2; }
unless($dst){ $dst=5; }

switch($threads){
	case 1 { $threads=1; }
	case [2..3] { $threads=2; }
	case [4..7] { $threads=4; }
	case [8..15] { $threads=8; }
	case [16..31] { $threads=16; }
	else { $threads=32; }
}

$d = int($n/$threads);

print "The number of threads used: $threads\n";

@sects = ();
for($i=0;$i<$threads;$i++){
	push @sects,$i*$d;
}
push @sects,$n;

print "@sects\n";

if($outfile){
	$subfold = "$outfile\_$subfold";
}
system("mkdir $subfold");

$pm = new Parallel::ForkManager($threads);
for($i=0;$i<$threads;$i++){
	$pid = $pm->start and next;
	print "Generating sub$i.hash ...\n";
	open(SUBOUT,">$subfold\/sub$i.hash");
	for($j=$sects[$i];$j<$sects[$i+1];$j++){
		$key = $keys[$j];
		$value = $hash{$key};
		print SUBOUT "$value\n$key\n";
	}
	close(SUBOUT);
    	$cmd = "$gmradfold\/bin\/clusterRead1 $subfold\/sub$i.hash $subfold\/subcls0\_$i $dst 0";
	system($cmd);
	$pm->finish;
}
$pm->wait_all_children;

$d = $threads;
$i = 0;
while($d>1){
	$d /= 2;
	$i++;
}
my $mergthread = 1;
$d = $i;
for($i=0;$i<$d;$i++){
	$threads /= 2;
	$mergthread *= 2;
	$pm = new Parallel::ForkManager($threads);
	for($j=0;$j<$threads;$j++){
		$pid = $pm->start and next;
		$j1 = 2*$j;
		$j2 = 2*$j + 1;
		$k = $i + 1;
    		$cmd = "$gmradfold\/bin\/merge2cls $subfold\/subcls$i\_$j1 $subfold\/subcls$i\_$j2  $subfold\/subcls$k\_$j $dst $mergthread";
		print "$cmd\n";
		system($cmd);
		$pm->finish;
	}
	$pm->wait_all_children;
}

$x = 2*$x + 1;
$i = 0;
if($outfile){
	open(IN,"<$subfold\/subcls$d\_0") || die "cannot find the file subcls$d\_0 in $subfold.\n";
	open(OUT,">$outfile.cls");
	while($line=<IN>){
		@flds = split /\s+/,$line;
		$n = scalar @flds;
		$n = $n - 1;
		if($n > 4 && $n < $x){
			$line =~ s/>cls\d+/>cls$i/;
			print OUT $line;
			$line = <IN>;
			print OUT $line;
			$i++;
		}else{
			$line = <IN>;
		}
		
	}
	close(IN);
	close(OUT);
}

exit;
