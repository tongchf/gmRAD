#! /usr/bin/perl -w

#    Copyright 2018 Chunfa Tong (tongchf@njfu.edu.cn)

#    This file is a part of gmRAD.

#    gmRAD is a free software package; you can redistribute it and/or 
#    modify it under the terms of the GNU General Public License as 
#    published by the Free Software Foundation; either version 3 of 
#    the License, or (at your option) any later version.

#    gmRAD is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with gmRAD. If not, see <http://www.gnu.org/licenses/>.

use strict;
use warnings;
use Getopt::Long;

sub prtHelp{
    print "This program is used to filter SNP genotype data from the file gmRawSNPs2.txt according to the SNP segregation type, the number of genotypes and the p value.\n";
    print "Contact: Chunfa Tong <tongchf\@njfu.edu.cn>\n";
    print "\n";
    print "Usage: perl filterGenotype.pl <gmRawSNPs2.txt>\n";
    print "\n";
    print "Parameters:\n";
    print "       -c <int> percent of the non-missing genotypes [90]\n";
    print "       -p <float> minimum p value [0.01]\n";
    print "       -o <str>  prefix for output files\n";
    print "       --help|h  help\n";
    print "\n";
}

my $pct;
my $segtyp;
my $pv;
my %hash;
my $line;
my @flds;
my ($n,$m,$i,$j);
my (@x1,$i1,$outf1);
my (@x2,$i2,$outf2);
my (@x3,$i3,$outf3);
my (@x4,$i4,$outf4);
my (@x5,$i5,$outf5);
my (@x6,$i6,$outf6);
my (@x7,$i7,$outf7);
my $allout;
my $allout2;
my ($workbook,$sheet);
my $help;
my $prfx;

GetOptions(
	"c:i"=>\$pct,
	"p:f"=>\$pv,
	"o:s"=>\$prfx,
	'help|h' => \$help
);

if($help){
	prtHelp();
	exit;
}

if(@ARGV<1){
	prtHelp();
	exit;
}

unless($pct){ $pct = 90; }
unless($pv){ $pv = 0.01; }
unless($prfx){ $prfx = ""; }

if($pct < 10 || $pct > 100){
	die "Error: Invalid value of the percent!\n";
}
if($pv < 0 || $pv > 1.0){
	die "Error: Invalid p value!\n";
}

open(IN,"<$ARGV[0]") || die "Error: cannot open the file $ARGV[0]!\n";
$line = <IN>;
chop $line;
@flds = split /\t/,$line;
$n = scalar @flds;
$n = $n - 10;
$m = $n*$pct/100.0;
$x1[0][0] = $flds[0];
$x1[0][1] = $flds[1];
$x1[0][2] = $flds[4];
$x1[0][$n+3] = $flds[9];
for($j=3;$j<($n+3);$j++){
		$x1[0][$j] = $flds[$j+7];
}
@x2 = @x1;
@x3 = @x1;
@x4 = @x1;
@x5 = @x1;
@x6 = @x1;
@x7 = @x1;
$i1 = 1;
$i2 = 1;
$i3 = 1;
$i4 = 1;
$i5 = 1;
$i6 = 1;
$i7 = 1;
while(<IN>){
	chop $_;
	@flds = split /\t/,$_;
	if($flds[4] eq "aaxab" ){
		if($flds[7] >= $m && $flds[9] > $pv){
			$x1[$i1][0] = $flds[0];
			$x1[$i1][1] = $flds[1];
			$x1[$i1][2] = $flds[4];
			$x1[$i1][$n+3] = $flds[9];
			for($j=3;$j<($n+3);$j++){
				$x1[$i1][$j] = $flds[$j+7];
			}
			$i1++;
		}
	}elsif($flds[4] eq "aaxbc" ){
		if($flds[7] >= $m && $flds[9] > $pv){
			$x2[$i2][0] = $flds[0];
			$x2[$i2][1] = $flds[1];
			$x2[$i2][2] = $flds[4];
			$x2[$i2][$n+3] = $flds[9];
			for($j=3;$j<($n+3);$j++){
				$x2[$i2][$j] = $flds[$j+7];
			}
			$i2++;
		}
	}elsif($flds[4] eq "abxaa" ){
		if($flds[7] >= $m && $flds[9] > $pv){
			$x3[$i3][0] = $flds[0];
			$x3[$i3][1] = $flds[1];
			$x3[$i3][2] = $flds[4];
			$x3[$i3][$n+3] = $flds[9];
			for($j=3;$j<($n+3);$j++){
				$x3[$i3][$j] = $flds[$j+7];
			}
			$i3++;
		}
	}elsif($flds[4] eq "abxcc" ){
		if($flds[7] >= $m && $flds[9] > $pv){
			$x4[$i4][0] = $flds[0];
			$x4[$i4][1] = $flds[1];
			$x4[$i4][2] = $flds[4];
			$x4[$i4][$n+3] = $flds[9];
			for($j=3;$j<($n+3);$j++){
				$x4[$i4][$j] = $flds[$j+7];
			}
			$i4++;
		}
	}elsif($flds[4] eq "abxab" ){
		if($flds[7] >= $m && $flds[9] > $pv){
			$x5[$i5][0] = $flds[0];
			$x5[$i5][1] = $flds[1];
			$x5[$i5][2] = $flds[4];
			$x5[$i5][$n+3] = $flds[9];
			for($j=3;$j<($n+3);$j++){
				$x5[$i5][$j] = $flds[$j+7];
			}
			$i5++;
		}
	}elsif($flds[4] eq "abxcd" ){
		if($flds[7] >= $m && $flds[9] > $pv){
			$x6[$i6][0] = $flds[0];
			$x6[$i6][1] = $flds[1];
			$x6[$i6][2] = $flds[4];
			$x6[$i6][$n+3] = $flds[9];
			for($j=3;$j<($n+3);$j++){
				$x6[$i6][$j] = $flds[$j+7];
			}
			$i6++;
		}
	}elsif($flds[4] eq "abxac" ){
		if($flds[7] >= $m && $flds[9] > $pv){
			$x7[$i7][0] = $flds[0];
			$x7[$i7][1] = $flds[1];
			$x7[$i7][2] = $flds[4];
			$x7[$i7][$n+3] = $flds[9];
			for($j=3;$j<($n+3);$j++){
				$x7[$i7][$j] = $flds[$j+7];
			}
			$i7++;
		}
	}
}
close(IN);

$outf1 = sprintf("$prfx\_aaxab_pct%dpv%02d.txt",$pct,$pv*100);
&filtergtp($outf1,@x1);
$outf2 = sprintf("$prfx\_aaxbc_pct%dpv%02d.txt",$pct,$pv*100);
&filtergtp($outf2,@x2);
$outf3 = sprintf("$prfx\_abxaa_pct%dpv%02d.txt",$pct,$pv*100);
&filtergtp($outf3,@x3);
$outf4 = sprintf("$prfx\_abxcc_pct%dpv%02d.txt",$pct,$pv*100);
&filtergtp($outf4,@x4);
$outf5 = sprintf("$prfx\_abxab_pct%dpv%02d.txt",$pct,$pv*100);
&filtergtp($outf5,@x5);
$outf6 = sprintf("$prfx\_abxcd_pct%dpv%02d.txt",$pct,$pv*100);
&filtergtp($outf6,@x6);
$outf7 = sprintf("$prfx\_abxac_pct%dpv%02d.txt",$pct,$pv*100);
&filtergtp($outf7,@x7);

exit;

sub filtergtp{
	my $outfile;
	my @x;
	my ($n,$m);
	my @ls;
	my ($i,$j,$k);
	my $pv0;

	$outfile = shift @_;
	@x = @_;
	$n = scalar @x;
	$m = scalar @{$x[0]};

	$ls[0] = 1;
	$j = 0;
	for($i=1;$i<($n-1);$i++){
		if($x[$i+1][0] ne $x[$i][0]){
			$j++;
			$ls[$j] = $i + 1;
		}
	}
	$ls[$j+1] = $n;

	open(OUT,">$outfile") || die "Error: cannot open the file $outfile\n";
	print OUT "SNP\t";	
	print OUT join("\t",@{$x[0]}[2..($m-2)]);
	print OUT "\n";
	if($n < 2){
		close(OUT);
		return 0;
	}
	for($i=0;$i<(scalar(@ls)-1);$i++){
		if($ls[$i] == ($ls[$i+1] - 1)){
			print OUT "$x[$ls[$i]][0]_$x[$ls[$i]][1]\t";
			print OUT join("\t",@{$x[$ls[$i]]}[2..($m-2)]);
			print OUT "\n";
		}else{
			$pv0 = 0.0;
			for($j=$ls[$i];$j<$ls[$i+1];$j++){
				if($x[$j][$m-1] > $pv0){
					$k = $j;
					$pv0 = $x[$j][$m-1];
				}		
			}
			print OUT "$x[$k][0]_$x[$k][1]\t";
			print OUT join("\t",@{$x[$k]}[2..($m-2)]);
			print OUT "\n";

		}
	}
	close(OUT);
}
