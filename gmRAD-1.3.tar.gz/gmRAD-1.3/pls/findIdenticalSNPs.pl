#!/usr/bin/perl -w

#    Copyright 2019 Chunfa Tong (tongchf@njfu.edu.cn)

#    This file is a part of gmRAD.

#    gmRAD is a free software package; you can redistribute it and/or 
#    modify it under the terms of the GNU General Public License as 
#    published by the Free Software Foundation; either version 3 of 
#    the License, or (at your option) any later version.

#    gmRAD is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with gmRAD. If not, see <http://www.gnu.org/licenses/>.

use strict;
use Parallel::ForkManager;
use Getopt::Long;
use Statistics::Distributions;

my @flds;
my $n;
my (@x,@y);
my ($n1,$n2);
my $np = 2;
my $pv = 0.01;
my $nmis = 90;
my $help;

sub Help{
	print "Usage: perl FindIdenticalSNPs.pl [Options]  <female.txt> <male.txt> <output file>\n\n";
	print "Options:\n";
	print "       -c <int>          non-missing percent of individuals [90]\n";
	print "       -p <float>        p-value [0.01]\n";
	print "       -t <int>          the number of threads\n";
	print "       --help | -h       help\n";
	exit;
}

GetOptions(
	'c:i' => \$nmis,
	'p:f' => \$pv,
	't:i' => \$np,
	'help|h' => \$help
);

if(@ARGV<3){
	Help();
	exit;
}

my ($i,$j,$k);
my $srgtype1;
my $srgtype2;
my $flag;

open(IN1,"<$ARGV[0]") || die "Error: cannot open the file $ARGV[0]!\n";
$n1 = 0;
while(<IN1>){
	chop $_;
	@flds = split /\s+/,$_;
	push @x,[@flds];
	$n1++;
}
close(IN1);
if($n1<2){
	print "Error: no SNP sites in file $ARGV[0]\n";
	exit;
}

$srgtype1 = $x[1][1];
for($i=2;$i<$n1;$i++){
	if($srgtype1 ne $x[$i][1]){
		print "Error: the segregation types are not consistent in file $ARGV[0]\n";
		exit;
	}
}

open(IN2,"<$ARGV[1]") || die "Error: cannot open the file $ARGV[1]!\n";
$n2 = 0;
while(<IN2>){
	chop $_;
	@flds = split /\s+/,$_;
	push @y,[@flds];
	$n2++;
}
close(IN2);
if($n2<2){
	print "Error: no SNP sites in file $ARGV[1]\n";
	exit;
}

$srgtype2 = $y[1][1];
for($i=2;$i<$n2;$i++){
	if($srgtype2 ne $y[$i][1]){
		print "Error: the segregation types are not consistent in file $ARGV[1]\n";
		exit;
	}
}

if($srgtype1 ne $srgtype2){
	print "Error: the segregation types are not consistent between files $ARGV[0] and $ARGV[1]\n";
	exit;
}

$n = scalar @flds;

my (@sects,$d);
my ($pm,$pid,$t);
my %hash;

if($n1 < $np){
	$np = 1;
}

$d = int($n1/$np);
for($i=0;$i<$np;$i++){
	push @sects,$i*$d;
}
push @sects,$n1;
$sects[0] = 1;

my ($j1,$j2);
my ($naa,$nab,$nbb,$ns);
my ($eaa,$eab,$ebb,$eac);
my ($nac,$nad,$nbc,$nbd);
my (@js,$nj);
my $value;
my ($x2,$p);
my @rst1;
my @rst0;
my @bst;
my @rst2;
my $nrst1;
my $minidvs;
my (@gtp,@gtp0);
my $nrst2;
my $ii;
my (@sij,@ls,@tmp);
my $ngtp;
my @si;
my $nsij;
my ($mini,$count,$besti);
my $ni;
my @gtp2;
my @gtp3;
my $ngtp2;
my $ngtp3;

$minidvs = ($n-2)*$nmis/100;

if($srgtype1 eq "aaxab" || $srgtype1 eq "abxaa"){
	oneone();
}

if($srgtype1 eq "aaxbc"){
	for($i=1;$i<$n1;$i++){
		for($j=2;$j<$n;$j++){
			if($x[$i][$j] eq "ac"){
				$x[$i][$j] = "aa";
			}
		}
	}
	for($i=1;$i<$n2;$i++){
		for($j=2;$j<$n;$j++){
			if($y[$i][$j] eq "ac"){
				$y[$i][$j] = "aa";
			}
		}
	}

	oneone();

	$ngtp3 = scalar @gtp3;
	for($i=1;$i<$ngtp3;$i++){
		for($j=2;$j<$n;$j++){
			if($gtp3[$i][$j] eq "aa"){
				$gtp3[$i][$j] = "ac";
			}
		}
	}
}

if($srgtype1 eq "abxcc"){
	for($i=1;$i<$n1;$i++){
		for($j=2;$j<$n;$j++){
			if($x[$i][$j] eq "ac"){
				$x[$i][$j] = "aa";
			}
			if($x[$i][$j] eq "bc"){
				$x[$i][$j] = "ab";
			}
		}
	}
	for($i=1;$i<$n2;$i++){
		for($j=2;$j<$n;$j++){
			if($y[$i][$j] eq "ac"){
				$y[$i][$j] = "aa";
			}
			if($y[$i][$j] eq "bc"){
				$y[$i][$j] = "ab";
			}
		}
	}

	oneone();

	$ngtp3 = scalar @gtp3;
	for($i=1;$i<$ngtp3;$i++){
		for($j=2;$j<$n;$j++){
			if($gtp3[$i][$j] eq "aa"){
				$gtp3[$i][$j] = "ac";
			}
			if($gtp3[$i][$j] eq "ab"){
				$gtp3[$i][$j] = "bc";
			}
		}
	}
}

if($srgtype1 eq "abxab"){
	onetwoone();
}

if($srgtype1 eq "abxcd"){
	allones();
}

if($srgtype1 eq "abxac"){
	for($i=1;$i<$n1;$i++){
		for($j=2;$j<$n;$j++){
			if($x[$i][$j] eq "ac"){
				$x[$i][$j] = "ad";
			}
			if($x[$i][$j] eq "bc"){
				$x[$i][$j] = "bd";
			}
			if($x[$i][$j] eq "aa"){
				$x[$i][$j] = "ac";
			}
			if($x[$i][$j] eq "ab"){
				$x[$i][$j] = "bc";
			}
		}
	}
	for($i=1;$i<$n2;$i++){
		for($j=2;$j<$n;$j++){
			if($y[$i][$j] eq "ac"){
				$y[$i][$j] = "ad";
			}
			if($y[$i][$j] eq "bc"){
				$y[$i][$j] = "bd";
			}
			if($y[$i][$j] eq "aa"){
				$y[$i][$j] = "ac";
			}
			if($y[$i][$j] eq "ab"){
				$y[$i][$j] = "bc";
			}
		}
	}

	allones();

	$ngtp3 = scalar @gtp3;
	for($i=1;$i<$ngtp3;$i++){
		for($j=2;$j<$n;$j++){
			if($gtp3[$i][$j] eq "ac"){
				$gtp3[$i][$j] = "aa";
			}
			if($gtp3[$i][$j] eq "ad"){
				$gtp3[$i][$j] = "ac";
			}
			if($gtp3[$i][$j] eq "bc"){
				$gtp3[$i][$j] = "ab";
			}
			if($gtp3[$i][$j] eq "bd"){
				$gtp3[$i][$j] = "bc";
			}
		}
	}
}

$ngtp3 = scalar @gtp3;
if($ngtp3>1){
	open(OUT,">$ARGV[2]");
	for($i=0;$i<$ngtp3;$i++){
		for($j=0;$j<$n;$j++){
			print OUT "$gtp3[$i][$j]\t";
		}
		print OUT "\n";
	}
	close(OUT);
}

system("rm temp*.txt");

exit;

sub allones{
	$pm = new Parallel::ForkManager($np);
	for($t=0;$t<$np;$t++){
		$pid = $pm->start and next;
		open(SUBOUT,">temp$t.txt");
		for($i=$sects[$t];$i<$sects[$t+1];$i++){
			for($j=1;$j<$n2;$j++){
				$flag = 1;
				for($k=2;$k<$n;$k++){
					if(($x[$i][$k] eq "ac" && $y[$j][$k] eq "ad") ||
					   ($x[$i][$k] eq "ac" && $y[$j][$k] eq "bc") ||
					   ($x[$i][$k] eq "ac" && $y[$j][$k] eq "bd") ||
					   ($x[$i][$k] eq "ad" && $y[$j][$k] eq "ac") ||
					   ($x[$i][$k] eq "ad" && $y[$j][$k] eq "bc") ||
					   ($x[$i][$k] eq "ad" && $y[$j][$k] eq "bd") ||
					   ($x[$i][$k] eq "bc" && $y[$j][$k] eq "ac") ||
					   ($x[$i][$k] eq "bc" && $y[$j][$k] eq "ad") ||
					   ($x[$i][$k] eq "bc" && $y[$j][$k] eq "bd") ||
					   ($x[$i][$k] eq "bd" && $y[$j][$k] eq "ac") ||
					   ($x[$i][$k] eq "bd" && $y[$j][$k] eq "ad") ||
					   ($x[$i][$k] eq "bd" && $y[$j][$k] eq "bc") ){
						$flag = 0;
						last;
					}
				}
				if($flag == 1){
					print SUBOUT "$i\t$j\n";
				}
			}
		}
		close(SUBOUT);
		$pm->finish;
	}
	$pm->wait_all_children;

	for($t=0;$t<$np;$t++){
		open(IN,"<temp$t.txt");
		while(<IN>){
			chop $_;
			@flds = split /\s+/,$_;
			if(exists $hash{$flds[0]}){
				$hash{$flds[0]} = "$hash{$flds[0]}\t$flds[1]";
			}else{
				$hash{$flds[0]} = $flds[1];
			}
		}
		close(IN);
	}
	
	foreach $i (sort {$a <=> $b} keys %hash){
		$value = $hash{$i};
		if($value =~ /\t/){
			@js = split /\t/,$value;
			$nj = scalar @js;
			$j = $js[0];
			@bst = srg1111($i,$j);
			for($j=1;$j<$nj;$j++){
				@rst0 = srg1111($i,$js[$j]);
				if($bst[6]<$rst0[6]){
					@bst = @rst0;
				}	
			}
		}else{
			$j = $value;
			@bst = srg1111($i,$j);
		}
		push @rst1,[@bst];
	}

	$nrst1 = scalar @rst1;
	for($i=0;$i<$nrst1;$i++){
		if($rst1[$i][6]>$minidvs && $rst1[$i][8]>$pv){
			push @rst2,[@{$rst1[$i]}];
		}
	}

	$nrst2 = scalar @rst2;
	push @gtp,[@{$x[0]}];
	for($ii=0;$ii<$nrst2;$ii++){
		$i = $rst2[$ii][0];
		$j = $rst2[$ii][1];
		@gtp0 = @{$x[$i]};
		for($k=2;$k<$n;$k++){
			if($gtp0[$k] ne $y[$j][$k]){
				$gtp0[$k] = "--";
			}
		}
		push @gtp,[@gtp0];
	}

	$ngtp = scalar @gtp;
	@ls = 1..$ngtp;
	for($i=1;$i<($ngtp-1);$i++){
		if($ls[$i] == 0){ next; };
		@tmp = ();
		push @tmp,$i;
		for($j=$i+1;$j<$ngtp;$j++){
			if($ls[$j] == 0){ next; }
			$flag = 1;
			for($k=2;$k<$n;$k++){
				if(($gtp[$i][$k] eq "ac" && $gtp[$j][$k] eq "ad") ||
				   ($gtp[$i][$k] eq "ac" && $gtp[$j][$k] eq "bc") ||
				   ($gtp[$i][$k] eq "ac" && $gtp[$j][$k] eq "bd") ||
				   ($gtp[$i][$k] eq "ad" && $gtp[$j][$k] eq "ac") ||
				   ($gtp[$i][$k] eq "ad" && $gtp[$j][$k] eq "bc") ||
				   ($gtp[$i][$k] eq "ad" && $gtp[$j][$k] eq "bd") ||
				   ($gtp[$i][$k] eq "bc" && $gtp[$j][$k] eq "ac") ||
				   ($gtp[$i][$k] eq "bc" && $gtp[$j][$k] eq "ad") ||
				   ($gtp[$i][$k] eq "bc" && $gtp[$j][$k] eq "bd") ||
				   ($gtp[$i][$k] eq "bd" && $gtp[$j][$k] eq "ac") ||
				   ($gtp[$i][$k] eq "bd" && $gtp[$j][$k] eq "ad") ||
				   ($gtp[$i][$k] eq "bd" && $gtp[$j][$k] eq "bc")){
					$flag = 0;
					last;
				}
			}
			if($flag == 1){
				push @tmp,$j;
				$ls[$j] = 0;
			}
		}
		if(scalar(@tmp)>1){
			$ls[$i] = 0;
			push @sij,[@tmp];
		}
	}

	$nsij = scalar @sij;
	for($i=0;$i<$nsij;$i++){
		$mini = $n;
		$ni = scalar @{$sij[$i]};
		for($j=0;$j<$ni;$j++){
			$ii = $sij[$i][$j];
			$count = 0;
			for($k=2;$k<$n;$k++){
				if($gtp[$ii][$k] eq "--"){
					$count++;
				}
			}
			if($mini>$count){
				$mini = $count;
				$besti = $ii;
			}
		}
		push @si,$besti;
	}

	foreach $i (@si){
		$ls[$i] = $ngtp;
	}

	for($i=0;$i<$ngtp;$i++){
		if($ls[$i] != 0){
			push @gtp2,[@{$gtp[$i]}];
		}
	}

	$ngtp2 = scalar @gtp2;
	push @gtp3,[@{$gtp2[0]}];
	for($i=1;$i<$ngtp2;$i++){
		$nac = 0;
		$nad = 0;
		$nbc = 0;
		$nbd = 0;
		for($j=2;$j<$n;$j++){
			if($gtp2[$i][$j] eq "ac"){ $nac++; }
			if($gtp2[$i][$j] eq "ad"){ $nad++; }
			if($gtp2[$i][$j] eq "bc"){ $nbc++; }
			if($gtp2[$i][$j] eq "bd"){ $nbd++; }
		}
		$ns = $nac + $nad + $nbc + $nbd;
		$eac = 0.25*$ns;
		$x2 = (($nac-$eac)**2 + ($nad-$eac)**2 + ($nbc-$eac)**2 + ($nbd-$eac)**2)/$eac;
		$p = Statistics::Distributions::chisqrprob(3,$x2);
		if($ns>$minidvs && $p>$pv){
			push @gtp3,[@{$gtp2[$i]}];
		}
	}
}

sub onetwoone{
	$pm = new Parallel::ForkManager($np);
	for($t=0;$t<$np;$t++){
		$pid = $pm->start and next;
		open(SUBOUT,">temp$t.txt");
		for($i=$sects[$t];$i<$sects[$t+1];$i++){
			for($j=1;$j<$n2;$j++){
				$flag = 1;
				for($k=2;$k<$n;$k++){
					if(($x[$i][$k] eq "aa" && $y[$j][$k] eq "ab") ||
					   ($x[$i][$k] eq "aa" && $y[$j][$k] eq "bb") ||
					   ($x[$i][$k] eq "ab" && $y[$j][$k] eq "aa") ||
					   ($x[$i][$k] eq "ab" && $y[$j][$k] eq "bb") ||
					   ($x[$i][$k] eq "bb" && $y[$j][$k] eq "aa") ||
					   ($x[$i][$k] eq "bb" && $y[$j][$k] eq "ab") ){
						$flag = 0;
						last;
					}
				}
				if($flag == 1){
					print SUBOUT "$i\t$j\n";
				}
			}
		}
		close(SUBOUT);
		$pm->finish;
	}
	$pm->wait_all_children;

	for($t=0;$t<$np;$t++){
		open(IN,"<temp$t.txt");
		while(<IN>){
			chop $_;
			@flds = split /\s+/,$_;
			if(exists $hash{$flds[0]}){
				$hash{$flds[0]} = "$hash{$flds[0]}\t$flds[1]";
			}else{
				$hash{$flds[0]} = $flds[1];
			}
		}
		close(IN);
	}

	foreach $i (sort {$a <=> $b} keys %hash){
		$value = $hash{$i};
		if($value =~ /\t/){
			@js = split /\t/,$value;
			$nj = scalar @js;
			$j = $js[0];
			@bst = srg121($i,$j);
			for($j=1;$j<$nj;$j++){
				@rst0 = srg121($i,$js[$j]);
				if($bst[5]<$rst0[5]){
					@bst = @rst0;
				}	
			}
		}else{
			$j = $value;
			@bst = srg121($i,$j);
		}
		push @rst1,[@bst];
	}

	$nrst1 = scalar @rst1;
	for($i=0;$i<$nrst1;$i++){
		if($rst1[$i][5]>$minidvs && $rst1[$i][7]>$pv){
			push @rst2,[@{$rst1[$i]}];
		}
	}

	$nrst2 = scalar @rst2;
	push @gtp,[@{$x[0]}];
	for($ii=0;$ii<$nrst2;$ii++){
		$i = $rst2[$ii][0];
		$j = $rst2[$ii][1];
		@gtp0 = @{$x[$i]};
		for($k=2;$k<$n;$k++){
			if($gtp0[$k] ne $y[$j][$k]){
				$gtp0[$k] = "--";
			}
		}
		push @gtp,[@gtp0];
	}

	$ngtp = scalar @gtp;
	@ls = 1..$ngtp;
	for($i=1;$i<($ngtp-1);$i++){
		if($ls[$i] == 0){ next; };
		@tmp = ();
		push @tmp,$i;
		for($j=$i+1;$j<$ngtp;$j++){
			if($ls[$j] == 0){ next; }
			$flag = 1;
			for($k=2;$k<$n;$k++){
				if(($gtp[$i][$k] eq "aa" && $gtp[$j][$k] eq "ab") ||
				   ($gtp[$i][$k] eq "aa" && $gtp[$j][$k] eq "bb") ||
				   ($gtp[$i][$k] eq "ab" && $gtp[$j][$k] eq "aa") ||
				   ($gtp[$i][$k] eq "ab" && $gtp[$j][$k] eq "bb") ||
				   ($gtp[$i][$k] eq "bb" && $gtp[$j][$k] eq "aa") ||
				   ($gtp[$i][$k] eq "bb" && $gtp[$j][$k] eq "ab")){
					$flag = 0;
					last;
				}
			}
			if($flag == 1){
				push @tmp,$j;
				$ls[$j] = 0;
			}
		}
		if(scalar(@tmp)>1){
			$ls[$i] = 0;
			push @sij,[@tmp];
		}
	}

	$nsij = scalar @sij;
	for($i=0;$i<$nsij;$i++){
		$mini = $n;
		$ni = scalar @{$sij[$i]};
		for($j=0;$j<$ni;$j++){
			$ii = $sij[$i][$j];
			$count = 0;
			for($k=2;$k<$n;$k++){
				if($gtp[$ii][$k] eq "--"){
					$count++;
				}
			}
			if($mini>$count){
				$mini = $count;
				$besti = $ii;
			}
		}
		push @si,$besti;
	}

	foreach $i (@si){
		$ls[$i] = $ngtp;
	}

	for($i=0;$i<$ngtp;$i++){
		if($ls[$i] != 0){
			push @gtp2,[@{$gtp[$i]}];
		}
	}

	$ngtp2 = scalar @gtp2;
	push @gtp3,[@{$gtp2[0]}];
	for($i=1;$i<$ngtp2;$i++){
		$naa = 0;
		$nab = 0;
		$nbb = 0;
		for($j=2;$j<$n;$j++){
			if($gtp2[$i][$j] eq "aa"){ $naa++; }
			if($gtp2[$i][$j] eq "ab"){ $nab++; }
			if($gtp2[$i][$j] eq "bb"){ $nbb++; }
		}
		$ns = $naa + $nab + $nbb;
		$eaa = 0.25*$ns;
		$eab = 0.5*$ns;
		$ebb = $eaa;
		$x2 = ($naa-$eaa)**2/$eaa + ($nab-$eab)**2/$eab + ($nbb-$ebb)**2/$ebb;
		$p = Statistics::Distributions::chisqrprob(2,$x2);
		if($ns>$minidvs && $p>$pv){
			push @gtp3,[@{$gtp2[$i]}];
		}
	}
}

sub oneone{
	$pm = new Parallel::ForkManager($np);
	for($t=0;$t<$np;$t++){
		$pid = $pm->start and next;
		open(SUBOUT,">temp$t.txt");
		for($i=$sects[$t];$i<$sects[$t+1];$i++){
			for($j=1;$j<$n2;$j++){
				$flag = 1;
				for($k=2;$k<$n;$k++){
					if(($x[$i][$k] eq "aa" && $y[$j][$k] eq "ab") ||
					   ($x[$i][$k] eq "ab" && $y[$j][$k] eq "aa") ){
						$flag = 0;
						last;
					}
				}
				if($flag == 1){
					print SUBOUT "$i\t$j\n";
				}
			}
		}
		close(SUBOUT);
		$pm->finish;
	}
	$pm->wait_all_children;

	for($t=0;$t<$np;$t++){
		open(IN,"<temp$t.txt");
		while(<IN>){
			chop $_;
			@flds = split /\s+/,$_;
			if(exists $hash{$flds[0]}){
				$hash{$flds[0]} = "$hash{$flds[0]}\t$flds[1]";
			}else{
				$hash{$flds[0]} = $flds[1];
			}
		}
		close(IN);
	}

	foreach $i (sort {$a <=> $b} keys %hash){
		$value = $hash{$i};
		if($value =~ /\t/){
			@js = split /\t/,$value;
			$nj = scalar @js;
			$j = $js[0];
			@bst = srg11($i,$j);
			for($j=1;$j<$nj;$j++){
				@rst0 = srg11($i,$js[$j]);
				if($bst[4]<$rst0[4]){
					@bst = @rst0;
				}	
			}
		}else{
			$j = $value;
			@bst = srg11($i,$j);
		}
		push @rst1,[@bst];
	}

	$nrst1 = scalar @rst1;
	for($i=0;$i<$nrst1;$i++){
		if($rst1[$i][4]>$minidvs && $rst1[$i][6]>$pv){
			push @rst2,[@{$rst1[$i]}];
		}
	}

	$nrst2 = scalar @rst2;
	push @gtp,[@{$x[0]}];
	for($ii=0;$ii<$nrst2;$ii++){
		$i = $rst2[$ii][0];
		$j = $rst2[$ii][1];
		@gtp0 = @{$x[$i]};
		for($k=2;$k<$n;$k++){
			if($gtp0[$k] ne $y[$j][$k]){
				$gtp0[$k] = "--";
			}
		}
		push @gtp,[@gtp0];
	}

	$ngtp = scalar @gtp;
	@ls = 1..$ngtp;
	for($i=1;$i<($ngtp-1);$i++){
		if($ls[$i] == 0){ next; };
		@tmp = ();
		push @tmp,$i;
		for($j=$i+1;$j<$ngtp;$j++){
			if($ls[$j] == 0){ next; }
			$flag = 1;
			for($k=2;$k<$n;$k++){
				if(($gtp[$i][$k] eq "aa" && $gtp[$j][$k] eq "ab") ||
				   ($gtp[$i][$k] eq "ab" && $gtp[$j][$k] eq "aa")){
					$flag = 0;
					last;
				}
			}
			if($flag == 1){
				push @tmp,$j;
				$ls[$j] = 0;
			}
		}
		if(scalar(@tmp)>1){
			$ls[$i] = 0;
			push @sij,[@tmp];
		}
	}

	$nsij = scalar @sij;
	for($i=0;$i<$nsij;$i++){
		$mini = $n;
		$ni = scalar @{$sij[$i]};
		for($j=0;$j<$ni;$j++){
			$ii = $sij[$i][$j];
			$count = 0;
			for($k=2;$k<$n;$k++){
				if($gtp[$ii][$k] eq "--"){
					$count++;
				}
			}
			if($mini>$count){
				$mini = $count;
				$besti = $ii;
			}
		}
		push @si,$besti;
	}

	foreach $i (@si){
		$ls[$i] = $ngtp;
	}

	for($i=0;$i<$ngtp;$i++){
		if($ls[$i] != 0){
			push @gtp2,[@{$gtp[$i]}];
		}
	}

	$ngtp2 = scalar @gtp2;
	push @gtp3,[@{$gtp2[0]}];
	for($i=1;$i<$ngtp2;$i++){
		$naa = 0;
		$nab = 0;
		for($j=2;$j<$n;$j++){
			if($gtp2[$i][$j] eq "aa"){ $naa++; }
			if($gtp2[$i][$j] eq "ab"){ $nab++; }
		}
		$ns = $naa + $nab;
		$x2 = ($naa - $nab)**2/$ns;
		$p = Statistics::Distributions::chisqrprob(1,$x2);
		if($ns>$minidvs && $p>$pv){
			push @gtp3,[@{$gtp2[$i]}];
		}
	}
}

sub srg11{
	my ($j1,$j2) = @_;
	my @tmp;
	$naa = 0;
	$nab = 0;
	for($k=2;$k<$n;$k++){
		if($x[$j1][$k] eq "aa" && $y[$j2][$k] eq "aa"){ $naa++; }
		if($x[$j1][$k] eq "ab" && $y[$j2][$k] eq "ab"){ $nab++; }
	}
	$ns = $naa + $nab;
	$x2 = ($naa - $nab)**2/$ns;
	$p = Statistics::Distributions::chisqrprob(1,$x2);
	@tmp = ($j1,$j2,$naa,$nab,$ns,$x2,$p);
	return @tmp;
}

sub srg121{
	my ($j1,$j2) = @_;
	my @tmp;
	$naa = 0;
	$nab = 0;
	$nbb = 0;
	for($k=2;$k<$n;$k++){
		if($x[$j1][$k] eq "aa" && $y[$j2][$k] eq "aa"){ $naa++; }
		if($x[$j1][$k] eq "ab" && $y[$j2][$k] eq "ab"){ $nab++; }
		if($x[$j1][$k] eq "bb" && $y[$j2][$k] eq "bb"){ $nbb++; }
	}
	$ns = $naa + $nab + $nbb;
	$eaa = 0.25*$ns;
	$eab = 0.5*$ns;
	$ebb = 0.25*$ns;
	$x2 = ($naa-$eaa)**2/$eaa + ($nab-$eab)**2/$eab + ($nbb-$ebb)**2/$ebb;
	$p = Statistics::Distributions::chisqrprob(2,$x2);
	@tmp = ($j1,$j2,$naa,$nab,$nbb,$ns,$x2,$p);
	return @tmp;
}

sub srg1111{
	my ($j1,$j2) = @_;
	my @tmp;
	$nac = 0;
	$nad = 0;
	$nbc = 0;
	$nbd = 0;
	for($k=2;$k<$n;$k++){
		if($x[$j1][$k] eq "ac" && $y[$j2][$k] eq "ac"){ $nac++; }
		if($x[$j1][$k] eq "ad" && $y[$j2][$k] eq "ad"){ $nad++; }
		if($x[$j1][$k] eq "bc" && $y[$j2][$k] eq "bc"){ $nbc++; }
		if($x[$j1][$k] eq "bd" && $y[$j2][$k] eq "bd"){ $nbd++; }
	}
	$ns = $nac + $nad + $nbc + $nbd;
	$eac = 0.25*$ns;
	$x2 = (($nac-$eac)**2 + ($nad-$eac)**2 + ($nbc-$eac)**2 + ($nbd-$eac)**2)/$eac;
	$p = Statistics::Distributions::chisqrprob(3,$x2);
	@tmp = ($j1,$j2,$nac,$nad,$nbc,$nbd,$ns,$x2,$p);
	return @tmp;
}
