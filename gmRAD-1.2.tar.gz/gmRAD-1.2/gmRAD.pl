#!/usr/bin/perl -w

#    Copyright 2018 Chunfa Tong (tongchf@njfu.edu.cn)

#    This file is a part of gmRAD.

#    gmRAD is a free software package; you can redistribute it and/or 
#    modify it under the terms of the GNU General Public License as 
#    published by the Free Software Foundation; either version 3 of 
#    the License, or (at your option) any later version.

#    gmRAD is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with gmRAD. If not, see <http://www.gnu.org/licenses/>.

use strict;
use warnings;
use Getopt::Long;
use Parallel::ForkManager;
use Excel::Writer::XLSX;

sub prtHelp{
    print "\ngmRAD is used to call SNP genotypes across a hybrid population with RAD-seq data for genetic linkage mapping. It takes five steps as following to finish the whole work.\n";
    print "	1. Clustering the first reads of each parent;\n";
    print "	2. Building the reference sequence within a cluster for each parent;\n";
    print "	3. Generating the parental SNP catalogs;\n";
    print "	4. Calling SNP genotypes across the individuals in the whole population;\n";
    print "	5. Filtering the SNP data by considering segregation ratio and missing data.\n\n";
    print "Contact: Chunfa Tong  <tongchf\@njfu.edu.cn>\n";
    print "Version: 1.0\n";
    print "Usage: perl gmRAD.pl [Options]\n";
    print "\n";
    print "Options:\n";
    print "       --nocluster  skip the step for clustering the first reads of each parent\n";
    print "       --nobuild    skip the step for building the parental reference sequences\n";
    print "       --nocatalog  skip the step for generating parental SNP catalogs\n";
    print "       --nocall     skip the step for calling SNP genotypes for all progeny\n";
    print "       --nofilter   skip the step for filtering the SNP genotype data\n";
    print "       --help|h     help\n";
}

my %prs;
my ($str1,$str2);
my $np;
my $cluster = 1;
my $build = 1;
my $catalog = 1;
my $call = 1;
my $filter = 1;
my $help;

GetOptions(
      	'cluster!' => \$cluster,
      	'build!' => \$build,
	'catalog!' => \$catalog,
	'call!' => \$call,
	'filter!' => \$filter,
	'help|h' => \$help
);

if($help){
	prtHelp();
	exit;
}

open(PRS,"<parameters.ini") || die "\nError\! This program needs a parameter file,namely \"parameters.ini\".\n\n";
$np = 0;
while(<PRS>){
	if(/:/){
		chop $_;
		($str1,$str2) = split /:/,$_;
		if($str1 =~ /\s*(\S+)\s*/){
			$str1 = $1;
			if($str2 =~ /\s*(\S+\s+\S+)\s*/ || 
			   $str2 =~ /\s*(\S+)\s*/){
				$str2 = $1;
				$prs{$str1} = $str2;
				if($str1 =~ /^\s*PROGENY\d+/){
					$np++;
				}
			}
		}
	}
}
close PRS;

my ($popradfold,$locasfold,$raddatafold);
my ($bwafold,$samtoolsfold,$bcftoolsfold);

if( exists( $prs{"GMRAD_FOLD"}) ){
	$popradfold = $prs{"GMRAD_FOLD"};
}else{
	die "Error! Please check the path of GMRAD in \"parameters.ini\".\n";
}

if( exists( $prs{"RADDATA_FOLD"}) ){
	$raddatafold = $prs{"RADDATA_FOLD"};
}else{
	die "Error! Please check the path of RAD data in \"parameters.ini\".\n";
}

if( exists( $prs{"LOCAS_FOLD"}) ){
	$locasfold = $prs{"LOCAS_FOLD"};
}else{
	die "Error! Please check the path of LOCAS in \"parameters.ini\".\n";
}

if( exists( $prs{BWA_FOLD}) ){
	$bwafold = $prs{"BWA_FOLD"};
}else{
	die "Error! Please check the path of bwa in \"parameters.ini\".\n";
}

if(exists($prs{"SAMTOOLS_FOLD"})){
	$samtoolsfold = $prs{"SAMTOOLS_FOLD"};
}else{
	die "Error! Please check the path of SAMtools in \"parameters.ini\".\n";
}

if(exists($prs{"BCFTOOLS_FOLD"})){
	$bcftoolsfold = $prs{"BCFTOOLS_FOLD"};
}else{
	die "Error! Please check the path of bcftools in \"parameters.ini\".\n";
}


my ($femaleparent1fq,$femaleparent2fq);
my ($maleparent1fq,$maleparent2fq);
my @prg1fq;
my @prg2fq;

if(exists($prs{"FEMALEPARENT"})){
	($femaleparent1fq,$femaleparent2fq) = split /\s+/,$prs{"FEMALEPARENT"};
	$str1 = "$raddatafold\/$femaleparent1fq";
	$str2 = "$raddatafold\/$femaleparent2fq";
	unless(-e $str1){
		die "Error\! The first fastq file of the female parent is wrong or does not exist.\n";
	}
	unless(-e $str2){
		die "Error\! The second fastq file of the female parent is wrong or does not exist.\n";
	}
}else{
	die "Error! Please check the line of FEMALEPARENT in \"parameters.ini\".\n";
}

if(exists($prs{"MALEPARENT"})){
	($maleparent1fq,$maleparent2fq) = split /\s+/,$prs{"MALEPARENT"};
	$str1 = "$raddatafold\/$maleparent1fq";
	$str2 = "$raddatafold\/$maleparent2fq";
	unless(-e $str1){
		die "Error\! The first fastq file of the male parent is wrong or does not exist.\n";
	}
	unless(-e $str2){
		die "Error\! The second fastq file of the male parent is wrong or does not exist.\n";
	}
}else{
	die "Error! Please check the line of MALEPARENT in \"parameters.ini\".\n";
}

my ($i,$j,$k);
my $str0;
my $flag;
my ($fqprfx0,@fqprfx);

for($i = 1;$i <= $np;$i++){
	$str0 = "PROGENY$i";
	if(exists($prs{$str0})){
		($prg1fq[$i-1],$prg2fq[$i-1]) = split /\s+/,$prs{$str0};
		$str1 = "$raddatafold\/$prg1fq[$i-1]";
		$str2 = "$raddatafold\/$prg2fq[$i-1]";
		unless(-e $str1){
			die "Error\! The first fastq file of progeny $i is wrong or does not exist.\n";
		}
		unless(-e $str2){
			die "Error\! The second fastq file of progeny $i is wrong or does not exist.\n";
		}

		($flag,$fqprfx0) = &prefixfq0($prg1fq[$i-1],$prg2fq[$i-1]);

		if($flag == 1){
			push @fqprfx,$fqprfx0;
		}else{
			die "Error: The file names of $prg1fq[$i-1] and $prg2fq[$i-1] are not consistent!\n";
			exit;
		}

	}else{
		die "Error! Please check the line of PROGENY$i in \"parameters.ini\".\n";
	}
}


my ($threads,$hmmdst,$edtdst,$genomerepeat,$alleldp,$gq,$mispct,$pvalue);

if(exists($prs{"THREADS"})){
	$threads = $prs{"THREADS"};
	unless( $threads =~ /\d+/ ){
		die "Error\! The number of threads is wrong.\n";
	}
}else{
	die "Error! Please check the line of THREADS in \"parameters.ini\".\n";
}

if(exists($prs{"ALLELDP"})){
	$alleldp = $prs{"ALLELDP"};
	unless( $alleldp =~ /\d+/ ){
		die "Error\! The allele depth  is wrong.\n";
	}
}else{
	die "Error! Please check the line of ALLELDP in \"parameters.ini\".\n";
}

if(exists($prs{"GQ"})){
	$gq = $prs{"GQ"};
	unless( $gq =~ /\d+/ ){
		die "Error\! The value of genotype quality (GQ) is wrong.\n";
	}
}else{
	die "Error! Please check the line of GQ in \"parameters.ini\".\n";
}

if(exists($prs{"EDITDST"})){
	$edtdst = $prs{"EDITDST"};
	unless( $edtdst =~ /\d+/ ){
		die "Error\! The edit distance  is wrong.\n";
	}
}else{
	die "Error! Please check the line of EDITDST in \"parameters.ini\".\n";
}

if(exists($prs{"HAMMDST"})){
	$hmmdst = $prs{"HAMMDST"};
	unless( $hmmdst =~ /\d+/ ){
		die "Error\! The hamming distance  is wrong.\n";
	}
}else{
	die "Error! Please check the line of HAMMDST in \"parameters.ini\".\n";
}

if(exists($prs{"GENOMEREPEAT"})){
	$genomerepeat = $prs{"GENOMEREPEAT"};
	unless( $genomerepeat =~ /\d+/ ){
		die "Error\! The number of threads is wrong.\n";
	}
	if($genomerepeat < 0 || $genomerepeat>100){	
		die "Error\! The parameter of GENOMEREPEAT  is wrong.\n";
	}	
}else{
	die "Error! Please check the line of GENOMEREPEAT in \"parameters.ini\".\n";
}

if(exists($prs{"MISPCT"})){
	$mispct = $prs{"MISPCT"};
	unless($mispct =~ /\d+/){
		die "Error\! The number for the percent of missing genotypes is wrong.\n";
	}
	if($mispct < 0 || $mispct > 100){	
		die "Error\! The parameter of MISPCT  is wrong.\n";
	}	
}

if(exists($prs{"PVALUE"})){
	$pvalue = $prs{"PVALUE"};
	if($pvalue < 0 || $pvalue > 1.0){	
		die "Error\! The parameter of PVALUE  is wrong.\n";
	}	
}

###################### Clustering the first reads for two parents ####################

my $cmd;
my ($binfold,$plsfold);
$binfold = "$popradfold\/bin";
$plsfold = "$popradfold\/pls";

if($cluster == 1){

	if(! -e "$plsfold\/clusteringRead1.pl"){
		die "Error: not find clusteringRead1.pl in $plsfold.\n";
	} 

	if(! -e "$binfold\/clusterRead1"){
		die "Error: not find the program clusterRead1 in $binfold.\n";
	}

	if(! -e "$binfold\/merge2cls"){
		die "Error: not find the program merge2cls in $binfold.\n";
	}

	print "\nNow,performing the clustering step ... \n\n";

	$cmd = "perl $plsfold\/clusteringRead1.pl $raddatafold\/$femaleparent1fq -t $threads -d $hmmdst -r $genomerepeat -p $popradfold -o femaleparent";
	system($cmd);

	$cmd = "perl $plsfold\/clusteringRead1.pl $raddatafold\/$maleparent1fq -t $threads -d $hmmdst -r $genomerepeat -p $popradfold -o maleparent";
	system($cmd);
}

###################### The end of clustering for the two parents #####################

################## Building the reference sequence within a cluster ##################

my ($perct1,$perct);
my @wds;
my ($x1,$x2);
my $line;

if($build == 1){


	unless(-e "femaleparent.cls"){
		die "Error: femaleparent.cls does not exist!\n";
	}
	unless(-e "maleparent.cls"){
		die "Error: maleparent.cls does not exist!\n";
	}

	$cmd = "perl $popradfold\/pls\/buildParentRef.pl -c femaleparent.cls -1 $raddatafold\/$femaleparent1fq -2 $raddatafold\/$femaleparent2fq -t $threads -r $locasfold -p $popradfold\/pls";
	system($cmd);
	system("mv ClustersRef.fasta femaleClustersRef.fasta");
	system("mv Read1ClsCons.fasta femaleRead1ClsCons.fasta");
	system("mv Read2ClsContig.fasta femaleRead2ClsContig.fasta");
	$cmd = "perl $popradfold\/pls\/buildParentRef.pl -c maleparent.cls -1 $raddatafold\/$maleparent1fq -2 $raddatafold\/$maleparent2fq -t $threads -r $locasfold -p $popradfold\/pls";
	system($cmd);
	system("mv ClustersRef.fasta maleClustersRef.fasta");
	system("mv Read1ClsCons.fasta maleRead1ClsCons.fasta");
	system("mv Read2ClsContig.fasta maleRead2ClsContig.fasta");
	
}
	
################## The end of building the reference sequence  ##################

##################     Generating parental SNP catalogs        ##################
my $fold;
my $allfold;
my ($pm,$pid);
my $head;
my (%hash,$key);
my $gtpfile;
my @fmpath = ("FemaleRef","MaleRef");
my @fmprfx = ("female","male");
my $reffile;
if($catalog == 1){
	if(! -e "femaleClustersRef.fasta"){
		print STDERR "Error: The reference file femaleClustersRef.fasta was not generated. Please perform the 'build' step!\n\n";
		exit;
	}
	if(! -e "maleClustersRef.fasta"){
		print STDERR "Error: The reference file maleClustersRef.fasta was not generated. Please perform the 'build' step!\n\n";
		exit;
	}
	
	$pm = new Parallel::ForkManager(2);
	for($i=0;$i<2;$i++){
		$pid = $pm->start and next;
		$fold = $fmpath[$i];
		if(-e $fold){
			system("rm -rf $fold");
		}
		mkdir $fold;
		$reffile = $fmprfx[$i]."ClustersRef.fasta";
		system("cp $reffile $fold");
		chdir $fold;
		$cmd = "perl $popradfold\/pls\/findParentsSNPs.pl -r $reffile -f1 $raddatafold\/$femaleparent1fq -f2 $raddatafold\/$femaleparent2fq -m1 $raddatafold\/$maleparent1fq -m2 $raddatafold\/$maleparent2fq -b $bwafold -s $samtoolsfold -c $bcftoolsfold -n $edtdst -o $fmprfx[$i]";
		system($cmd);
		
		$pm->finish;
	}
	$pm->wait_all_children;

#	$cmd = "perl $popradfold\/pls\/findParentsSNPs.pl -r maleClustersRef.fasta -f1 $raddatafold\/$femaleparent1fq -f2 $raddatafold\/$femaleparent2fq -m1 $raddatafold\/$maleparent1fq -m2 $raddatafold\/$maleparent2fq -b $bwafold -s $samtoolsfold -c $bcftoolsfold -n $edtdst -o male";
#	system($cmd);
}

################## The end of generating parental SNP catalogs  #################

##################          Calling SNPs for all progeny        #################
if($call == 1){
	if(! -e "FemaleRef"){
		print STDERR "Error: The fold 'FemaleRef' did not exist. Please perform the 'catalog' step!\n";
		exit;
	}
	if(! -e "MaleRef"){
		print STDERR "Error: The fold 'MaleRef' did not exist. Please perform the 'catalog' step!\n";
		exit;
	}
	
	chdir "FemaleRef";
	if(! -e "femaleClustersRef.fasta"){
		print STDERR "Error: The reference file femaleClustersRef.fasta was not generated. Please perform the 'build' step!\n\n";
		exit;
	}
	if(! -e "female_gtp.loc"){
		print STDERR "Error: The catalog file female_gtp.loc was not generated. Please perform the 'generating catalog' step!\n\n";
		exit;
	}
	if(! -e "female.gtp"){
		print STDERR "Error: The female genotype file female.gtp was not generated. Please perform the 'generating catalog' step!\n\n";
		exit;
	}

	if($np<$threads){
		$threads = $np;
	}

	$allfold = "FemaleRefProgenyGenotype";
	if(-e $allfold){
		system("rm -rf $allfold");
	}
	mkdir $allfold;

	$pm = new Parallel::ForkManager($threads);
	for($i=0;$i<$threads;$i++){
		$pid = $pm->start and next;
		$fold = "CallFemaleRefProgenyGTP$i";
		if(-e $fold){
			system("rm -rf $fold");
		}
		mkdir $fold;
		system("cp femaleClustersRef.fasta $fold");
		system("cp female_gtp.loc $fold");
		chdir $fold;
		for($j=$i;$j<$np;$j+=$threads){
			$cmd = "perl $popradfold\/pls\/findProgenySNPs.pl -r femaleClustersRef.fasta -f female_gtp.loc -1 $raddatafold\/$prg1fq[$j] -2 $raddatafold\/$prg2fq[$j] -b $bwafold -s $samtoolsfold -c $bcftoolsfold -n $edtdst -d $alleldp";
			system($cmd);
			if(-e "$fqprfx[$j].gtp"){
				system("cp $fqprfx[$j].gtp ..\/$allfold");
			}
		}
		$pm->finish;
	}
	$pm->wait_all_children;
	
	$head = "SEQ\tPOS\tFEMALE\tMALE";
	open(IN,"<female.gtp") || die "Error: female.gtp does not exist!\n";
	while(<IN>){
		chop $_;
		@wds = split /\t/,$_;
		$key = "$wds[0]\t$wds[1]";
		$hash{$key} = $_;
	}
	close(IN);

	for($i=0;$i<$np;$i++){
		$gtpfile = "$allfold\/$fqprfx[$i].gtp";
		if(-e $gtpfile){
			$head = "$head\t$fqprfx[$i]";
			open(IN,"<$gtpfile");
			while(<IN>){
				chop $_;
				@wds = split /\t/,$_;
				$key = "$wds[0]\t$wds[1]";
				$hash{$key} = "$hash{$key}\t$wds[2]";
			}
			close(IN);
		}
	}

	open(OUT,">FemaleRefRawSNPs.txt");
	print OUT "$head\n";
	foreach $key ( sort { ($a=~/(\d+)\t(\d+)/)[0] <=> ($b=~/(\d+)\t(\d+)/)[0]
        		   or ($a=~/(\d+)\t(\d+)/)[1] <=> ($b=~/(\d+)\t(\d+)/)[1] 
			}  (keys %hash)){
		print OUT "$hash{$key}\n";
	}
	close OUT;
	system("cp FemaleRefRawSNPs.txt ..");

	chdir "../MaleRef";
	if(! -e "maleClustersRef.fasta"){
		print STDERR "Error: The reference file maleClustersRef.fasta was not generated. Please perform the 'build' step!\n\n";
		exit;
	}
	if(! -e "male_gtp.loc"){
		print STDERR "Error: The catalog file male_gtp.loc was not generated. Please perform the 'generating catalog' step!\n\n";
		exit;
	}
	if(! -e "male.gtp"){
		print STDERR "Error: The male genotype file male.gtp was not generated. Please perform the 'generating catalog' step!\n\n";
		exit;
	}

	%hash = ();
	$allfold = "MaleRefProgenyGenotype";
	if(-e $allfold){
		system("rm -rf $allfold");
	}
	mkdir $allfold;

	$pm = new Parallel::ForkManager($threads);
	for($i=0;$i<$threads;$i++){
		$pid = $pm->start and next;
		$fold = "CallMaleRefProgenyGTP$i";
		if(-e $fold){
			system("rm -rf $fold");
		}
		mkdir $fold;
		system("cp maleClustersRef.fasta $fold");
		system("cp male_gtp.loc $fold");
		chdir $fold;
		for($j=$i;$j<$np;$j+=$threads){
			$cmd = "perl $popradfold\/pls\/findProgenySNPs.pl -r maleClustersRef.fasta -f male_gtp.loc -1 $raddatafold\/$prg1fq[$j] -2 $raddatafold\/$prg2fq[$j] -b $bwafold -s $samtoolsfold -c $bcftoolsfold -n $edtdst -d $alleldp";
			system($cmd);
			if(-e "$fqprfx[$j].gtp"){
				system("cp $fqprfx[$j].gtp ..\/$allfold");
			}
		}
		$pm->finish;
	}
	$pm->wait_all_children;

	$head = "SEQ\tPOS\tFEMALE\tMALE";

	open(IN,"<male.gtp") || die "Error: male.gtp does not exist!\n";
	while(<IN>){
		chop $_;
		@wds = split /\t/,$_;
		$key = "$wds[0]\t$wds[1]";
		$hash{$key} = $_;
	}
	close(IN);

	for($i=0;$i<$np;$i++){
		$gtpfile = "$allfold\/$fqprfx[$i].gtp";
		if(-e $gtpfile){
			$head = "$head\t$fqprfx[$i]";
			open(IN,"<$gtpfile");
			while(<IN>){
				chop $_;
				@wds = split /\t/,$_;
				$key = "$wds[0]\t$wds[1]";
				$hash{$key} = "$hash{$key}\t$wds[2]";
			}
			close(IN);
		}
	}

	open(OUT,">MaleRefRawSNPs.txt");
	print OUT "$head\n";
	foreach $key ( sort { ($a=~/(\d+)\t(\d+)/)[0] <=> ($b=~/(\d+)\t(\d+)/)[0]
        		   or ($a=~/(\d+)\t(\d+)/)[1] <=> ($b=~/(\d+)\t(\d+)/)[1] 
			}  (keys %hash)){
		print OUT "$hash{$key}\n";
	}
	close OUT;
	system("cp MaleRefRawSNPs.txt ..");
	chdir "..";
}

############################ The end of calling SNPs  ##########################

############################   Filtering genotypes      ########################
if($filter == 1){
	if(! -e "FemaleRefRawSNPs.txt"){
		print STDERR "Error: The raw SNP file FemaleRefRawSNPs.txt was not generated. Please perform the calling step!\n\n";
		exit;
	}
	$cmd = "perl $popradfold\/pls\/filterRawSNPs.pl FemaleRefRawSNPs.txt FemaleRefRawSNPs2.txt";
	system($cmd);
	$cmd = "perl $popradfold\/pls\/filterGenotype.pl FemaleRefRawSNPs2.txt -c $mispct -p $pvalue -o FemaleRef";
	system($cmd);
	if(! -e "MaleRefRawSNPs.txt"){
		print STDERR "Error: The raw SNP file MaleRefRawSNPs.txt was not generated. Please perform the calling step!\n\n";
		exit;
	}
	$cmd = "perl $popradfold\/pls\/filterRawSNPs.pl MaleRefRawSNPs.txt MaleRefRawSNPs2.txt";
	system($cmd);
	$cmd = "perl $popradfold\/pls\/filterGenotype.pl MaleRefRawSNPs2.txt -c $mispct -p $pvalue -o MaleRef";
	system($cmd);

	my $infile1;
	my $infile2;	
	my $outfile;

	open(OUT,">identicalSNPsList.txt");

	$infile1 = sprintf("FemaleRef\_aaxab_pct%dpv%02d.txt",$mispct,$pvalue*100);
	$infile2 = sprintf("MaleRef\_aaxab_pct%dpv%02d.txt",$mispct,$pvalue*100);
	$outfile = sprintf("aaxab_pct%dpv%02d.txt",$mispct,$pvalue*100);
	$cmd = "perl $popradfold\/pls\/findIdenticalSNPs.pl $infile1 $infile2 $outfile\_0";
	system($cmd);
	$cmd = "perl $popradfold\/pls\/filterBinSNPs.pl $outfile\_0 $outfile";
	system($cmd);
	system("rm $outfile\_0");

	$infile1 = sprintf("FemaleRef\_abxaa_pct%dpv%02d.txt",$mispct,$pvalue*100);
	$infile2 = sprintf("MaleRef\_abxaa_pct%dpv%02d.txt",$mispct,$pvalue*100);
	$outfile = sprintf("abxaa_pct%dpv%02d.txt",$mispct,$pvalue*100);
	$cmd = "perl $popradfold\/pls\/findIdenticalSNPs.pl $infile1 $infile2 $outfile\_0";
	system($cmd);
	$cmd = "perl $popradfold\/pls\/filterBinSNPs.pl $outfile\_0 $outfile";
	system($cmd);
	system("rm $outfile\_0");

	$infile1 = sprintf("FemaleRef\_abxab_pct%dpv%02d.txt",$mispct,$pvalue*100);
	$infile2 = sprintf("MaleRef\_abxab_pct%dpv%02d.txt",$mispct,$pvalue*100);
	$outfile = sprintf("abxab_pct%dpv%02d.txt",$mispct,$pvalue*100);
	$cmd = "perl $popradfold\/pls\/findIdenticalSNPs.pl $infile1 $infile2 $outfile\_0";
	system($cmd);
	$cmd = "perl $popradfold\/pls\/filterBinSNPs.pl $outfile\_0 $outfile";
	system($cmd);
	system("rm $outfile\_0");

	$infile1 = sprintf("FemaleRef\_abxcd_pct%dpv%02d.txt",$mispct,$pvalue*100);
	$infile2 = sprintf("MaleRef\_abxcd_pct%dpv%02d.txt",$mispct,$pvalue*100);
	$outfile = sprintf("abxcd_pct%dpv%02d.txt",$mispct,$pvalue*100);
	$cmd = "perl $popradfold\/pls\/findIdenticalSNPs.pl $infile1 $infile2 $outfile\_0";
	system($cmd);
	$cmd = "perl $popradfold\/pls\/filterBinSNPs.pl $outfile\_0 $outfile";
	system($cmd);
	system("rm $outfile\_0");

	$infile1 = sprintf("FemaleRef\_aaxbc_pct%dpv%02d.txt",$mispct,$pvalue*100);
	$infile2 = sprintf("MaleRef\_aaxbc_pct%dpv%02d.txt",$mispct,$pvalue*100);
	$outfile = sprintf("aaxbc_pct%dpv%02d.txt",$mispct,$pvalue*100);
	$cmd = "perl $popradfold\/pls\/findIdenticalSNPs.pl $infile1 $infile2 $outfile\_0";
	system($cmd);
	$cmd = "perl $popradfold\/pls\/filterBinSNPs.pl $outfile\_0 $outfile";
	system($cmd);
	system("rm $outfile\_0");

	$infile1 = sprintf("FemaleRef\_abxcc_pct%dpv%02d.txt",$mispct,$pvalue*100);
	$infile2 = sprintf("MaleRef\_abxcc_pct%dpv%02d.txt",$mispct,$pvalue*100);
	$outfile = sprintf("abxcc_pct%dpv%02d.txt",$mispct,$pvalue*100);
	$cmd = "perl $popradfold\/pls\/findIdenticalSNPs.pl $infile1 $infile2 $outfile\_0";
	system($cmd);
	$cmd = "perl $popradfold\/pls\/filterBinSNPs.pl $outfile\_0 $outfile";
	system($cmd);
	system("rm $outfile\_0");

	$infile1 = sprintf("FemaleRef\_abxac_pct%dpv%02d.txt",$mispct,$pvalue*100);
	$infile2 = sprintf("MaleRef\_abxac_pct%dpv%02d.txt",$mispct,$pvalue*100);
	$outfile = sprintf("abxac_pct%dpv%02d.txt",$mispct,$pvalue*100);
	$cmd = "perl $popradfold\/pls\/findIdenticalSNPs.pl $infile1 $infile2 $outfile\_0";
	system($cmd);
	$cmd = "perl $popradfold\/pls\/filterBinSNPs.pl $outfile\_0 $outfile";
	system($cmd);
	system("rm $outfile\_0");

	close(OUT);
	
	$cmd = "perl $popradfold\/pls\/write2JoinMap.pl -c $mispct -p $pvalue -n $np";
	system($cmd);

}

############################  The end of filtering genotypes ###################

exit;


sub prefixfq0{
	my ($fq1,$fq2) = @_;
	my $i;
	my ($n1,$n2);
	my ($s1,$s2);
	my $prefix;
	my @tmp;

	$n1 = length($fq1);
	$n2 = length($fq2);

	if($n1 != $n2){
		return (0,"");
	}

	for($i=0;$i<$n1;$i++){
		$s1 = substr($fq1,$i,1);
		$s2 = substr($fq2,$i,1);
		if($s1 ne $s2 && $s1 eq "1" && $s2 eq "2" && $i>0){
			$prefix = substr($fq1,0,$i);
			$prefix =~ s/[-\_\._]$//;
			if($prefix=~/\//){
				@tmp = split /\//,$prefix;
				$prefix = pop @tmp;
			}
			return (1,$prefix);
		}	
	}

	return (0,"");
}

