#!/usr/bin/perl -w

#    Copyright 2018 Chunfa Tong (tongchf@njfu.edu.cn)

#    This file is a part of gmRAD.

#    gmRAD is a free software package; you can redistribute it and/or 
#    modify it under the terms of the GNU General Public License as 
#    published by the Free Software Foundation; either version 3 of 
#    the License, or (at your option) any later version.

#    gmRAD is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with gmRAD. If not, see <http://www.gnu.org/licenses/>.

use strict;
use warnings;

my ($i,$j,$k);
my %hash;
my $line;
my $lth;
my ($key,$value);
my (@ns,$n);
my (@str,$nstr);
my $clsid;
my $outfile;

if(@ARGV<2){
	print "This program is used to call the consensus sequence for the left RAD-seq reads in a cluster. It will generate a fasta format file,namely CoCls\$clsid\_R1Consensus.fasta.\n";
	die "Usage: perl callR1ClsConsensus.pl <read1.fq> <clsid>\n"; 
}

open(IN,"<$ARGV[0]");
while($line = <IN>){
	$line = <IN>;
	chop $line;
	$lth = length($line);
	if(exists $hash{$lth}){
		$hash{$lth} = "$hash{$lth}\n$line";
	}else{
		$hash{$lth} = $line;
	}
	$line = <IN>;
	$line = <IN>;
}

@ns = sort {$a<=>$b} keys %hash;
unshift @ns,0;
$n = scalar @ns;

my ($start,$sublen);
my %subhash;
my $ss;
my $conseq = "";
for($i=1;$i<$n;$i++){
	$start = $ns[$i-1];
	$sublen = $ns[$i] - $start;
	%subhash = ();
	for($j=$i;$j<$n;$j++){
		@str = split /\n/,$hash{$ns[$j]};
		$nstr = scalar @str;
		for($k=0;$k<$nstr;$k++){
			$ss = substr($str[$k],$start,$sublen);
			$subhash{$ss}++;
		}
	}
	foreach $key (sort {$subhash{$b}<=>$subhash{$a}} keys %subhash){
		$value = $subhash{$key};
		$conseq = $conseq.$key;
		last;
	}
		
}

$clsid = $ARGV[1];
$outfile = "Cls$clsid\_R1Consensus.fasta";
open(OUT,">$outfile") || die "Cannot open the file: $outfile.\n";
print OUT ">Cls$clsid\_read1_consensus\n";
print OUT "$conseq\n";
close(OUT);
exit;
