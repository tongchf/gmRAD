#!/usr/bin/perl -w

#    Copyright 2018 Chunfa Tong (tongchf@njfu.edu.cn)

#    This file is a part of gmRAD.

#    gmRAD is a free software package; you can redistribute it and/or 
#    modify it under the terms of the GNU General Public License as 
#    published by the Free Software Foundation; either version 3 of 
#    the License, or (at your option) any later version.

#    gmRAD is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with gmRAD. If not, see <http://www.gnu.org/licenses/>.

use strict;

my %hash;
my %hashrst;
my %snpPos;
my $line0;
my @flds;
my $key;
my $value;
my $n;

if(@ARGV<2){
	print "Usage: perl FindIdenticalSNPs.pl <female.txt> <male.txt> <output file>\n\n";
	exit;
}

open(IN1,"<$ARGV[0]") || die "Error: cannot open the file $ARGV[0]!\n";
$line0 = <IN1>;
while(<IN1>){
	chop $_;
	@flds = split /\s+/,$_;
	$n = scalar @flds;
	$key = join("  ",@flds[1..($n-1)]);
	$hash{$key} = "$flds[0]";
}
close(IN1);

open(IN2,"<$ARGV[1]") || die "Error: cannot open the file $ARGV[1]!\n";
$line0 = <IN2>;
while(<IN2>){
	chop $_;
	@flds = split /\s+/,$_;
	$n = scalar @flds;
	$key = join("  ",@flds[1..($n-1)]);
	if(exists($hash{$key})){
		$value = $hash{$key};
		$hash{$key} = "$value\tM$flds[0]";
		if($value =~ /CLS(\d+)\_(\d+)\tM(.*)/){
			$snpPos{"FCLS$1\_$2"} = "M$3\tM$flds[0]";
		}else{
			$value =~ /CLS(\d+)\_(\d+)/;
			$snpPos{"FCLS$1\_$2"} = "M$flds[0]";
		}
	}
}
close(IN2);

%hashrst = ();
foreach $key ( keys %hash ){
	$value = $hash{$key};
	if($value =~ /CLS(\d+)\_(\d+)\t/){
		$hashrst{$1} = "\_$2  $key";
	}
}

open(OUT,">$ARGV[2]") || die "Error: cannot open the file $ARGV[2]!\n";
print OUT $line0;
foreach $key (sort {$a <=> $b} keys %hashrst){
	$value = $hashrst{$key};
	print OUT "CLS$key$value\n";
}
close(OUT);

open(OUT2,">>identicalSNPsList.txt");
foreach $key (sort { ($a=~/FCLS(\d+)\_(\d+)/)[0] <=> ($b=~/FCLS(\d+)\_(\d+)/)[0] } keys %snpPos){
	$value = $snpPos{$key};
	print OUT2 "$key\t$value\n";
}
close(OUT2);

exit;
