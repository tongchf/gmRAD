#!/usr/bin/perl -w

#    Copyright 2018 Chunfa Tong (tongchf@njfu.edu.cn)

#    This file is a part of gmRAD.

#    gmRAD is a free software package; you can redistribute it and/or 
#    modify it under the terms of the GNU General Public License as 
#    published by the Free Software Foundation; either version 3 of 
#    the License, or (at your option) any later version.

#    gmRAD is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with gmRAD. If not, see <http://www.gnu.org/licenses/>.

use strict;
use warnings;

my %hash;
my $line;
my @wds;
my ($n,$nw);
my ($key,$value);

if(@ARGV==0){
    	print "This program is for generating the distribution of the number of the reads in hash clusters in RAD-seq data\n";
    	print "Contact: Chunfa Tong  <tongchf\@njfu.edu.cn>\n";
    	print "Usage: perl distribR1Hash.pl <parent.hash> \n";
	exit;
}

open(IN,"<$ARGV[0]") || die "Error: The file $ARGV[1] does not exist!\n";
$n = 0;
while($line = <IN>){
	@wds = split /\s+/,$line;
	$nw = scalar @wds;
	$hash{$nw}++;
	$line = <IN>;
	$n += $nw;
}
close(IN);

print "n = $n\n";

open(OUT,">distribution_for\_$ARGV[0]");
print OUT "NO.\tNum_reads_within_cluster\tNum_cluster\tCluster_cumulant\tNum_reads\tReads_umulant\tPercent\n";
my $i;
my $nrd;
my ($cmtcls,$cmtrds);
my $pct;

$i = 1;
$cmtcls = 0;
$cmtrds = 0;
foreach $key (sort {$a <=> $b} keys %hash){
	$value = $hash{$key};
	$cmtcls += $value;
	$nrd = $key*$value;
	$cmtrds += $nrd;
	$pct = $cmtrds/$n*100;
	printf OUT "$i\t$key\t$value\t$cmtcls\t$nrd\t$cmtrds\t%5.2f\n",$pct;
	$i++;
}
close (OUT);
exit;
