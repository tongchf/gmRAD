#! /usr/bin/perl -w

#    Copyright 2018 Chunfa Tong (tongchf@njfu.edu.cn)

#    This file is a part of gmRAD.

#    gmRAD is a free software package; you can redistribute it and/or 
#    modify it under the terms of the GNU General Public License as 
#    published by the Free Software Foundation; either version 3 of 
#    the License, or (at your option) any later version.

#    gmRAD is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with gmRAD. If not, see <http://www.gnu.org/licenses/>.

use strict;
use warnings;
use Parallel::ForkManager;
use Getopt::Long;

sub prtHelp{
    print "This program is used to generate RAD reference sequences for one parent with its read1 cluster information and fastq files.\n";
    print "Contact: Chunfa Tong <tongchf\@njfu.edu.cn>\n";
    print "\n";
    print "Usage: perl buildParentRef.pl <-c parent.cls> ... <-p perl_script_path>\n";
    print "\n";
    print "Parameters:\n";
    print "       -c <string> the cluster information file *.cls\n";
    print "       -1 <string> the read1 fastq file of the parent\n";
    print "       -2 <string> the read2 fastq file of the parent\n";
    print "       -t <int> the number of threads to be used [2]\n";
    print "       -r <string> the program LOCAS path\n";
    print "       -p <string> the path of this perl program\n";
    print "       --help|h  help\n";
    print "\n";
}

my $clsfile;
my $n;
my $nline;
my $line;
my ($i,$j,$k);
my ($read1fq,$read2fq);
my (@fqfile1,@fqfile2);
my @fqid;
my $id;
my $threads = 2;
my $cpui;
my $subdir;
my @ls;
my ($pid,$pm);
our $popradpath;
our $LOCASpath;
our (@cls,@st);
my $ncls;
my $clsi;
my $help;

GetOptions(
	"c:s"=>\$clsfile,
	"1:s"=>\$read1fq,
	"2:s"=>\$read2fq,
	"t:i"=>\$threads,
	"r:s"=>\$LOCASpath,
	"p:s"=>\$popradpath,
        "help|h" => \$help
);

if($help){
     	prtHelp();
	exit;
}

unless($clsfile && $read1fq && $read2fq && $LOCASpath && $popradpath){
	prtHelp();
	exit;
}
if($LOCASpath =~ /^\.+\//){
	print "Error: please give the absolute path for LOCAS!\n";
	prtHelp();
	exit;
}
unless(-e "$LOCASpath\/locas"){
	print "Error: The program locas does not exist in $LOCASpath!\n";
	prtHelp();
	exit;
}
if($popradpath =~ /^\.+\//){
	print "Error: please give the absolute path for PopRAD!\n";
	prtHelp();
	exit;
}
unless(-e "$popradpath\/callR1ClsConsensus.pl"){
	print "Error: The program callR1ClsConsensus.pl does not exist in $popradpath!\n";
	prtHelp();
	exit;
}
unless(-e "$popradpath\/assembleR2Cls.pl"){
	print "Error: The program assembleR2Cls.pl does not exist in $popradpath!\n";
	prtHelp();
	exit;
}
unless(-e "$popradpath\/joinR1consR2contig.pl"){
	print "Error: The program joinR1consR2contig.pl does not exist in $popradpath!\n";
	prtHelp();
	exit;
}

$ncls = 0;
open (IN,"$clsfile") || die "Error: cannot open the file $clsfile!\n";
while($line=<IN>){
	$ncls++;
	chop $line;
	$line =~ />cls\d+\s+(.*)/;
	push @cls,$1;
	$line = <IN>;
}
close IN;
print "ncls = $ncls\n";

if($ncls%$threads==0){
	$n = $ncls/$threads;	
}else{
	$n = int($ncls/$threads)+1;
}
for($i=0;$i<$threads;$i++){
	$st[$i] = $i*$n;
}
$st[$threads] = $ncls;
print "@st\n";

@fqfile1 = ();
open (FQ1,"<$read1fq") or die "Error: cannot open the file $read1fq!\n";
push @fqfile1,tell(FQ1);
while(<FQ1>){
	push @fqfile1,tell(FQ1);
}
pop @fqfile1;

@fqfile2 = ();
open (FQ2,"<$read2fq") or die "Error: cannot open the file $read2fq!\n";
push @fqfile2,tell(FQ2);
while(<FQ2>){
	push @fqfile2,tell(FQ2);
}
pop @fqfile2;

$n = scalar @fqfile1;
print "n = $n\n\n";

for($cpui=0;$cpui<$threads;$cpui++)
{
	$subdir = "$clsfile.ref$cpui";
	if(-e $subdir){
		system("rm -rf $subdir");
	}
	system("mkdir $subdir");
	open (F1,">$subdir\/f1.fq");
	open (F2,">$subdir\/f2.fq");
	for($clsi = $st[$cpui]; $clsi < $st[$cpui+1]; $clsi++){
		@fqid = split /\s+/,$cls[$clsi];
		$n = scalar @fqid;
		for($j=0;$j<$n;$j++){
			$id = $fqid[$j]*4;
			seek(FQ1,$fqfile1[$id],0);
			seek(FQ2,$fqfile2[$id],0);
			$line = <FQ1>;
			print F1 $line;
			$line = <FQ1>;
			print F1 $line;
			$line = <FQ1>;
			print F1 $line;
			$line = <FQ1>;
			print F1 $line;
			$line = <FQ2>;
			print F2 $line;
			$line = <FQ2>;
			print F2 $line;
			$line = <FQ2>;
			print F2 $line;
			$line = <FQ2>;
			print F2 $line;
		}
	}
	close F1;
	close F2;
}
close FQ1;
close FQ2;

$pm = new Parallel::ForkManager($threads);
for($cpui=0;$cpui<$threads;$cpui++){
	$pid = $pm->start and next;
	generateBlockRef($cpui);
	$pm->finish;
}
$pm->wait_all_children;

my ($read1consfile,$read2contigfile,$reffile);
open(R1,">Read1ClsCons.fasta");
open(R2,">Read2ClsContig.fasta");
open(REF,">ClustersRef.fasta");
for($cpui=0;$cpui<$threads;$cpui++){
	$read1consfile = "$clsfile.ref$cpui\/read1consens$cpui";
	$read2contigfile = "$clsfile.ref$cpui\/read2contig$cpui";
	$reffile = "$clsfile.ref$cpui\/reffasta$cpui";
	if(-e $read1consfile){
		open(IN,$read1consfile);
		while(<IN>){
			print R1 $_;
		}
		close IN;
	}else{
		die "The file $read1consfile does not exist!\n";
	}
	if(-e $read2contigfile){
		open(IN,$read2contigfile);
		while(<IN>){
			print R2 $_;
		}
		close IN;
	}else{
		die "The file $read2contigfile does not exist!\n";
	}
	if(-e $reffile){
		open(IN,$reffile);
		while(<IN>){
			print REF $_;
		}
		close IN;
	}else{
		die "The file $reffile does not exist!\n";
	}
}
close R1;
close R2;
close REF;
exit;

sub generateBlockRef{
	my $cpui =  $_[0];
	my $subdir;
	my $clsi;
	my @fqid;
	my $clsid;
	my $line;
	my ($i,$n);
	my $nline;
	my $cmd;
	my ($path1,$path2,$path3);

	$subdir = "$clsfile.ref$cpui";
	chdir $subdir;
	open (REF,">reffasta$cpui");
	open (R1,">read1consens$cpui");
	open (R2,">read2contig$cpui");
	open (F1,"<f1.fq");
	open (F2,"<f2.fq");
	for($clsi = $st[$cpui]; $clsi < $st[$cpui+1]; $clsi++){
		@fqid = split /\s+/,$cls[$clsi];
		$n = scalar @fqid;
		$clsid = "Cls$clsi";
		open (OUTF1,">$clsid\_1.fq") or die;
		open (OUTF2,">$clsid\_2.fq") or die;

		for($i=0;$i<$n;$i++){
			$line = <F1>;
			print OUTF1 "\@$clsid\_$fqid[$i]\n";
			$line = <F1>;
			print OUTF1 $line;
			$line = <F1>;
			print OUTF1 $line;
			$line = <F1>;
			print OUTF1 $line;
			$line = <F2>;
			print OUTF2 "\@$clsid\_$fqid[$i]\n";
			$line = <F2>;
			print OUTF2 $line;
			$line = <F2>;
			print OUTF2 $line;
			$line = <F2>;
			print OUTF2 $line;
		}
		close OUTF1;
		close OUTF2;

		$cmd = "perl $popradpath\/callR1ClsConsensus.pl $clsid\_1.fq $clsi";
		system($cmd);
#		$cmd = "perl $popradpath\/assemblR2Cls.pl $clsid\_2.fq $RApiDpath $clsi";
		$cmd = "perl $popradpath\/assembleR2Cls.pl -i $clsid\_2.fq -l 21-47-2 -f fastq -a $LOCASpath -o $clsid\_R2Contig.fasta";
		system($cmd);
	
		$path1 ="$clsid\_R1Consensus.fasta";
		if(-e $path1){
			open (IN1,$path1);
			while (<IN1>){
				print R1 $_;
			}
			close IN1;
		}
		$path2 ="$clsid\_R2Contig.fasta";
		$nline = readpipe("wc -l $path2 | awk '{print \$1}'");
		if($nline == 2){
			open (IN2,$path2);
			while (<IN2>){
				print R2 $_;
			}
			close IN2;

			$cmd = "perl $popradpath\/joinR1consR2contig.pl $path1 $path2 $clsi";
			system($cmd);
		}
		
		$path3 ="$clsid\_R1joinR2\_ref.fasta";
		if(-e $path3){
			open (IN3,$path3);
			while (<IN3>){
				print REF $_;
			}
			close IN3;
		}

		system("rm -rf *error *contig *contigs tmp*");
		system("rm Cls*");
	}

	close F1;
	close F2;
	close REF;
	close R2;
	close R1;
}

