#!/usr/bin/perl -w

#    Copyright 2018 Chunfa Tong (tongchf@njfu.edu.cn)

#    This file is a part of gmRAD.

#    gmRAD is a free software package; you can redistribute it and/or 
#    modify it under the terms of the GNU General Public License as 
#    published by the Free Software Foundation; either version 3 of 
#    the License, or (at your option) any later version.

#    gmRAD is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with gmRAD. If not, see <http://www.gnu.org/licenses/>.

use strict;

my $head;
my ($m,$n);
my ($i,$j,$k);
my @x;
my @ls;
my $seg;
my @flds;
my ($n1,$n2,$n3,$n4);
my ($n5,$n6,$n7,$n8,$n9);
my ($n10,$n11,$n12,$n13,$n14,$n15,$n16);
my ($sn1,$sn2);
my $kk;

if(@ARGV<1){
	die "Usage: perl filterBinSNPs.pl <input file> <output file>\n";
}

open(IN,"<$ARGV[0]") || die "Error: cannot open the file $ARGV[0]!\n";
$head = <IN>;
while(<IN>){
	chop $_;
	@flds = split /\s+/,$_;
	push @x,[@flds];
}
close(IN);

$n = scalar @x;
unless($n){
	die "Warning: The input file contains no SNPs!\n";
}
$m = scalar @{$x[0]};
$seg = $x[0][1];
print "n = $n, m = $m\n";
print "seq = $seg\n";

@ls = 1..$n;
if($seg eq "aaxab" || $seg eq "abxaa"){
	for($i=0;$i<($n-1);$i++){
		if($ls[$i] == 0){
			next;
		}
		for($j=$i+1;$j<$n;$j++){
			if($ls[$j] == 0){
				next;
			}
			$n1 = $n2 = $n3 = $n4 = 0;
			for($k=2;$k<$m;$k++){
				if($x[$i][$k] eq "aa" && $x[$j][$k] eq "aa"){
					$n1++;
				}elsif($x[$i][$k] eq "aa" && $x[$j][$k] eq "ab"){
					$n2++;
				}elsif($x[$i][$k] eq "ab" && $x[$j][$k] eq "aa"){
					$n3++;
				}elsif($x[$i][$k] eq "ab" && $x[$j][$k] eq "ab"){
					$n4++;
				}
				$kk = $k;
				if(($n2+$n3)>0 && ($n1+$n4)>0){
					last;
				}
			}		
			if($kk == ($m-1) && (($n2+$n3) == 0 || ($n1+$n4) == 0)){
				$ls[$j] = 0;
			}
		}
	}
}

if($seg eq "abxab"){
	for($i=0;$i<($n-1);$i++){
		if($ls[$i] == 0){
			next;
		}
		for($j=$i+1;$j<$n;$j++){
			if($ls[$j] == 0){
				next;
			}
			$n1 = $n2 = $n3 = $n4 = 0;
			$n5 = $n6 = $n7 = $n8 = $n9 = 0;
			for($k=2;$k<$m;$k++){
				if($x[$i][$k] eq "aa" && $x[$j][$k] eq "aa"){
					$n1++;
				}elsif($x[$i][$k] eq "aa" && $x[$j][$k] eq "ab"){
					$n2++;
				}elsif($x[$i][$k] eq "aa" && $x[$j][$k] eq "bb"){
					$n3++;
				}elsif($x[$i][$k] eq "ab" && $x[$j][$k] eq "aa"){
					$n4++;
				}elsif($x[$i][$k] eq "ab" && $x[$j][$k] eq "ab"){
					$n5++;
				}elsif($x[$i][$k] eq "ab" && $x[$j][$k] eq "bb"){
					$n6++;
				}elsif($x[$i][$k] eq "bb" && $x[$j][$k] eq "aa"){
					$n7++;
				}elsif($x[$i][$k] eq "bb" && $x[$j][$k] eq "ab"){
					$n8++;
				}elsif($x[$i][$k] eq "bb" && $x[$j][$k] eq "bb"){
					$n9++;
				}
				$kk = $k;
				$sn1 = $n2+$n3+$n4+$n5+$n6+$n7+$n8;
				$sn2 = $n1+$n3+$n5+$n7+$n9;
				if($sn1>0 && $sn2>0){
					last;
				}
			}		
			if($kk == ($m-1) && ($sn1 == 0 || $sn2 == 0)){
				$ls[$j] = 0;
			}
		}
	}
}

if($seg eq "aaxbc"){
	for($i=0;$i<($n-1);$i++){
		if($ls[$i] == 0){
			next;
		}
		for($j=$i+1;$j<$n;$j++){
			if($ls[$j] == 0){
				next;
			}
			$n1 = $n2 = $n3 = $n4 = 0;
			for($k=2;$k<$m;$k++){
				if($x[$i][$k] eq "ab" && $x[$j][$k] eq "ab"){
					$n1++;
				}elsif($x[$i][$k] eq "ab" && $x[$j][$k] eq "ac"){
					$n2++;
				}elsif($x[$i][$k] eq "ac" && $x[$j][$k] eq "ab"){
					$n3++;
				}elsif($x[$i][$k] eq "ac" && $x[$j][$k] eq "ac"){
					$n4++;
				}
				$kk = $k;
				if(($n2+$n3)>0 && ($n1+$n4)>0){
					last;
				}
			}		
			if($kk == ($m-1) && (($n2+$n3) == 0 || ($n1+$n4) == 0)){
				$ls[$j] = 0;
			}
		}
	}
}

if($seg eq "abxcc"){
	for($i=0;$i<($n-1);$i++){
		if($ls[$i] == 0){
			next;
		}
		for($j=$i+1;$j<$n;$j++){
			if($ls[$j] == 0){
				next;
			}
			$n1 = $n2 = $n3 = $n4 = 0;
			for($k=2;$k<$m;$k++){
				if($x[$i][$k] eq "ac" && $x[$j][$k] eq "ac"){
					$n1++;
				}elsif($x[$i][$k] eq "ac" && $x[$j][$k] eq "bc"){
					$n2++;
				}elsif($x[$i][$k] eq "bc" && $x[$j][$k] eq "ac"){
					$n3++;
				}elsif($x[$i][$k] eq "bc" && $x[$j][$k] eq "bc"){
					$n4++;
				}
				$kk = $k;
				if(($n2+$n3)>0 && ($n1+$n4)>0){
					last;
				}
			}		
			if($kk == ($m-1) && (($n2+$n3) == 0 || ($n1+$n4) == 0)){
				$ls[$j] = 0;
			}
		}
	}
}

if($seg eq "abxcd"){
	for($i=0;$i<($n-1);$i++){
		if($ls[$i] == 0){
			next;
		}
		for($j=$i+1;$j<$n;$j++){
			if($ls[$j] == 0){
				next;
			}
			$n1 = $n2 = $n3 = $n4 = 0;
			$n5 = $n6 = $n7 = $n8 = $n9 = 0;
			$n10 = $n11 = $n12 = $n13 = 0;
			$n14 = $n15 = $n16 = 0;
			for($k=2;$k<$m;$k++){
				if($x[$i][$k] eq "ac" && $x[$j][$k] eq "ac"){
					$n1++;
				}elsif($x[$i][$k] eq "ac" && $x[$j][$k] eq "ad"){
					$n2++;
				}elsif($x[$i][$k] eq "ac" && $x[$j][$k] eq "bc"){
					$n3++;
				}elsif($x[$i][$k] eq "ac" && $x[$j][$k] eq "bd"){
					$n4++;
				}elsif($x[$i][$k] eq "ad" && $x[$j][$k] eq "ac"){
					$n5++;
				}elsif($x[$i][$k] eq "ad" && $x[$j][$k] eq "ad"){
					$n6++;
				}elsif($x[$i][$k] eq "ad" && $x[$j][$k] eq "bc"){
					$n7++;
				}elsif($x[$i][$k] eq "ad" && $x[$j][$k] eq "bd"){
					$n8++;
				}elsif($x[$i][$k] eq "bc" && $x[$j][$k] eq "ac"){
					$n9++;
				}elsif($x[$i][$k] eq "bc" && $x[$j][$k] eq "ad"){
					$n10++;
				}elsif($x[$i][$k] eq "bc" && $x[$j][$k] eq "bc"){
					$n11++;
				}elsif($x[$i][$k] eq "bc" && $x[$j][$k] eq "bd"){
					$n12++;
				}elsif($x[$i][$k] eq "bd" && $x[$j][$k] eq "ac"){
					$n13++;
				}elsif($x[$i][$k] eq "bd" && $x[$j][$k] eq "ad"){
					$n14++;
				}elsif($x[$i][$k] eq "bd" && $x[$j][$k] eq "bc"){
					$n15++;
				}elsif($x[$i][$k] eq "bd" && $x[$j][$k] eq "bd"){
					$n16++;
				}
				$kk = $k;
				$sn1 = $n2+$n3+$n4+$n5+$n7+$n8+$n9+$n10+$n12+$n13+$n14+$n15;
				$sn2 = $n1+$n3+$n4+$n6+$n7+$n8+$n9+$n10+$n11+$n13+$n14+$n16;
				if($sn1>0 && $sn2>0){
					last;
				}
			}		
			if($kk == ($m-1) && ($sn1 == 0 || $sn2 == 0)){
				$ls[$j] = 0;
			}
		}
	}
}

if($seg eq "abxac"){
	for($i=0;$i<($n-1);$i++){
		if($ls[$i] == 0){
			next;
		}
		for($j=$i+1;$j<$n;$j++){
			if($ls[$j] == 0){
				next;
			}
			$n1 = $n2 = $n3 = $n4 = 0;
			$n5 = $n6 = $n7 = $n8 = $n9 = 0;
			$n10 = $n11 = $n12 = $n13 = 0;
			$n14 = $n15 = $n16 = 0;
			for($k=2;$k<$m;$k++){
				if($x[$i][$k] eq "aa" && $x[$j][$k] eq "aa"){
					$n1++;
				}elsif($x[$i][$k] eq "aa" && $x[$j][$k] eq "ac"){
					$n2++;
				}elsif($x[$i][$k] eq "aa" && $x[$j][$k] eq "ab"){
					$n3++;
				}elsif($x[$i][$k] eq "aa" && $x[$j][$k] eq "bc"){
					$n4++;
				}elsif($x[$i][$k] eq "ac" && $x[$j][$k] eq "aa"){
					$n5++;
				}elsif($x[$i][$k] eq "ac" && $x[$j][$k] eq "ac"){
					$n6++;
				}elsif($x[$i][$k] eq "ac" && $x[$j][$k] eq "ab"){
					$n7++;
				}elsif($x[$i][$k] eq "ac" && $x[$j][$k] eq "bc"){
					$n8++;
				}elsif($x[$i][$k] eq "ab" && $x[$j][$k] eq "aa"){
					$n9++;
				}elsif($x[$i][$k] eq "ab" && $x[$j][$k] eq "ac"){
					$n10++;
				}elsif($x[$i][$k] eq "ab" && $x[$j][$k] eq "ab"){
					$n11++;
				}elsif($x[$i][$k] eq "ab" && $x[$j][$k] eq "bc"){
					$n12++;
				}elsif($x[$i][$k] eq "bc" && $x[$j][$k] eq "aa"){
					$n13++;
				}elsif($x[$i][$k] eq "bc" && $x[$j][$k] eq "ac"){
					$n14++;
				}elsif($x[$i][$k] eq "bc" && $x[$j][$k] eq "ab"){
					$n15++;
				}elsif($x[$i][$k] eq "bc" && $x[$j][$k] eq "bc"){
					$n16++;
				}
				$kk = $k;
				$sn1 = $n2+$n3+$n4+$n5+$n7+$n8+$n9+$n10+$n12+$n13+$n14+$n15;
				$sn2 = $n1+$n3+$n4+$n6+$n7+$n8+$n9+$n10+$n11+$n13+$n14+$n16;
				if($sn1>0 && $sn2>0){
					last;
				}
			}		
			if($kk == ($m-1) && ($sn1 == 0 || $sn2 == 0)){
				$ls[$j] = 0;
			}
		}
	}
}

open(OUT,">$ARGV[1]") || die "Error: cannot open the file $ARGV[1]!\n";
chop $head;
@flds = split /\s+/,$head;
print OUT "@flds\n";
for($i=0;$i<$n;$i++){
	if($ls[$i] > 0){
		print OUT "@{$x[$i]}\n";
	}
}
close(OUT);

exit;
