#! /usr/bin/perl -w

#    Copyright 2018 Chunfa Tong (tongchf@njfu.edu.cn)

#    This file is a part of gmRAD.

#    gmRAD is a free software package; you can redistribute it and/or 
#    modify it under the terms of the GNU General Public License as 
#    published by the Free Software Foundation; either version 3 of 
#    the License, or (at your option) any later version.

#    gmRAD is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with gmRAD. If not, see <http://www.gnu.org/licenses/>.

use strict;
use warnings;
use Getopt::Long;

my $bwafold;
my $samtoolsfold;
my $bcftoolsfold;
my $reffile;
my $cosnploc;

my ($i,$j,$k);
my ($fq1,$fq2);
my $cmd;
my $flag;
my $prefix;
my $edtdst;
my $help;

sub prtHelp{
	print "\nThis program is used to call progeny SNPs with a common-locus file generated from the parental fastq data.\n\n";
	print "Contact: Chunfa Tong <tongchf\@njfu.edu.cn>\n";
	print "Usage: perl findProgenySNPs.pl <-r ref.fa> <-f common.loc> <-1 read1.fq> <-2 read2.fq> ...\n\n";
	print "Parameters are accepted as following:\n";
	print "		-r  <str>	the reference file in fasta format\n";
	print "		-f  <str>	the common-locus file\n";
	print "		-1 <str>	the read1 fastq file\n";
	print "		-2 <str>	the read2 fastq file\n";
	print "		-b  <str>	BWA fold\n";
	print "		-s  <str>	SAMtools fold\n";
	print "		-c  <str>	BCFtools fold\n";
	print "		-n  <int>	maximum edit distance (i.e. NM:i:xxx in SAM file)\n";
	print "		--help | -h	help\n";
	exit;
}

GetOptions(
	"r:s"=>\$reffile,
	"f:s"=>\$cosnploc,
	"1:s"=>\$fq1,
	"2:s"=>\$fq2,
	"b:s"=>\$bwafold,
	"s:s"=>\$samtoolsfold,
	"c:s"=>\$bcftoolsfold,
	"n:i"=>\$edtdst,
	"help|h"=>\$help
);

if($help){
	prtHelp();
	exit;
}

unless($reffile){
	print STDERR "\nError: the reference fasta file was not provided!\n\n";
	prtHelp();
	exit;
}

unless($cosnploc){
	print STDERR "\nError: the common-locus file was not provided!\n\n";
	prtHelp();
	exit;
}


unless($fq1){
	print STDERR "\nError: the read1 fastq file was not provided!\n\n";
	prtHelp();
	exit;
}

unless($fq2){
	print STDERR "\nError: the read2 fastq file was not provided!\n\n";
	prtHelp();
	exit;
}

unless($bwafold){
	print STDERR "\nError: BWA fold was not provided!\n\n";
	prtHelp();
	exit;
}

unless($samtoolsfold){
	print STDERR "\nError: SAMtools fold was not provided!\n\n";
	prtHelp();
	exit;
}

unless($bcftoolsfold){
	print STDERR "\nError: BCFtools fold was not provided!\n\n";
	prtHelp();
	exit;
}

unless($edtdst){
	print STDERR "\nError: the edit distance was not provided!\n\n";
	prtHelp();
	exit;
}

($flag,$prefix) = &prefixfq($fq1,$fq2);

if($flag != 1){
	die "Error: The file names of $fq1 and $fq2 are not consistent!\n";
}

## Please add the checking information about the fastq files in the future.

		$cmd = "$bwafold\/bwa index  $reffile";
		system($cmd);

		$cmd = "$bwafold\/bwa mem $reffile $fq1 $fq2 > $prefix.sam";
		system($cmd);
		
		filterProgenySAM("$prefix.sam","$prefix.b.sam",$edtdst);

 		$cmd = "$samtoolsfold\/samtools view -b -S -o $prefix.bam $prefix.b.sam";
		system($cmd);
 
		$cmd = "$samtoolsfold\/samtools sort $prefix.bam -o $prefix.sorted.bam";
		system($cmd);
		$cmd = "$samtoolsfold\/samtools index $prefix.sorted.bam";
		system($cmd);
		$cmd = "$samtoolsfold\/samtools mpileup -uv -t DPR,INFO/DPR -g -f $reffile $prefix.sorted.bam > $prefix.bcf";
		system($cmd);
		
		$cmd = "$bcftoolsfold\/bcftools call -m -f gq -T $cosnploc $prefix.bcf | awk '\$1!~/^#/' > $prefix.vcf";
		system($cmd);

my %hash;

%hash = ();
open(SNP,"<$cosnploc");
while(<SNP>){
	chop $_;
	$hash{$_} = ".";	
}
close SNP;

my @fd;
my $key;
my @allels;
my $gtp0;
my ($a1,$a2);
my @gtp;
my ($dp0,$dp1,$dp2,@dp);
my $gq;

open(SNP,"<$prefix.vcf");
while(<SNP>){
	chop $_;
	@fd = split /\t/,$_;
	$key = "$fd[0]\t$fd[1]";
	if(exists $hash{$key} && $fd[7] !~ /INDEL/){
		if($fd[8] =~ /GT:DPR/){
			($gtp0,$dp0) = split /:/,$fd[9];
			if($gtp0 eq "0\/0" && $dp0 > 4){
				$hash{$key} = "$fd[3]|$fd[3]";
			}
		}
		if($fd[8] =~ /GT:PL:DPR:GQ/){
			if($fd[4]=~/,/){
				@allels = ($fd[3],(split /,/,$fd[4]));
			}else{
				@allels = ($fd[3],$fd[4]);
			}
			($gtp0,undef,$dp0,$gq) = split /:/,$fd[9];
			($a1,$a2) = split /\//,$gtp0;
			@dp = split /,/,$dp0;
			if($a1 == $a2){
				$dp0 = $dp[$a1];
				if($dp0 > 4){
					$gtp0 = "$allels[$a1]|$allels[$a1]";		
					$hash{$key} = $gtp0;
				}		
			}else{
				$dp1 = $dp[$a1];
				$dp2 = $dp[$a2];
				if($dp1>2 && $dp2>2 && $gq>30){
					@gtp = sort ($allels[$a1],$allels[$a2]);
					$hash{$key} = "$gtp[0]|$gtp[1]";	
				}
			}
		}
	}
}
close SNP;

open(GTP,">$prefix.gtp0");
foreach $key (keys %hash){
	print GTP "$key\t$hash{$key}\n";
}
close(GTP);

$cmd = "sort -n -k 1.4 -k 2 $prefix.gtp0 > $prefix.gtp";
system($cmd);

system("rm *.sam *.bam *.bai *.bcf *gtp0");

exit;


sub filterProgenySAM{
	#	print "Usage: filterProgenySAM(in.sam,out.sam,mismatch)\n";
	my ($inputsam,$outputsam,$msmt) = @_;
	my @fd;
	my $lth;
	my $minas;

	open(FILE,"<$inputsam") || die "Could not open the SAM file\n";
	open(OUT,">$outputsam");

	while(<FILE>){
		if($_=~/^\@SQ/){
			print OUT $_;
			next;
		}
		@fd = split /\s+/,$_;
		if($fd[2] eq "*" || $fd[3] == $fd[7] || ($fd[3] != 1 && $fd[7] != 1)){
			next;
		}
		if(/NM:i:(\d+)\s+AS:i:(\d+)\s+XS:i:(\d+)/){
			$lth = length($fd[9]);
			$minas = $lth - $msmt*5;
			if($1<=$msmt && $2>$3 && $2 >= $minas){ 
				print OUT $_;
			}
		}
	}
	close FILE;
	close OUT;
}

sub prefixfq{
	my ($fq1,$fq2) = @_;
	my $i;
	my ($n1,$n2);
	my ($s1,$s2);
	my $prefix;
	my @tmp;

	$n1 = length($fq1);
	$n2 = length($fq2);

	if($n1 != $n2){
		return (0,"");
	}

	for($i=0;$i<$n1;$i++){
		$s1 = substr($fq1,$i,1);
		$s2 = substr($fq2,$i,1);
		if($s1 ne $s2 && $s1 eq "1" && $s2 eq "2" && $i>0){
			$prefix = substr($fq1,0,$i);
			$prefix =~ s/[-\_\._]$//;
			if($prefix=~/\//){
				@tmp = split /\//,$prefix;
				$prefix = pop @tmp;
			}
			return (1,$prefix);
		}	
	}

	return (0,"");
}
